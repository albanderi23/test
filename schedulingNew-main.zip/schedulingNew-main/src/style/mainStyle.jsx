import { border, transition } from "@chakra-ui/react";
import { color, transform } from "framer-motion";

const design = {
  input: {
    boxShadow: "inner",
    borderRadius: "1rem",
    border: "1px solid silver",
    bg: "white",
    ":focus": {
      boxShadow: "inner",
    },
  },

  periods: {
    morning: {
      color: "#87bceb",
      name: "صباح",
      fontColor: "white",
    },
    afternoon: {
      color: "#6A89D2",
      name: "ظهر",
      fontColor: "white",
    },
    evening: {
      color: "#4e57ba",
      name: "مساء",
      fontColor: "white",
    },
    default: {
      color: "#121B3F",
      name: "لا يوجد",
      fontColor: "white",
    },
    deleted: {
      color: "#ffa9a9",
      name: "حذف",
      fontColor: "black",
    },
  },

  select: {
    bg: "white",
    boxShadow: "inner",
    color: "black",
    borderRadius: "1rem",
    border: "1px solid silver",
  },
  button: {
    primary: {
      borderRadius: "1rem",
      fontWeight: "bold",
      color: "#f0f0f0",
      bg: "#121B3F",
      ":hover": { bg: "#121B3F" },
      transition: ".1s",
      boxShadow: "0 3px #444D71",
      border: "solid 1px #444D71",
      ":active": {
        boxShadow: "0 0 #444D71",
        transform: "translateY(3px)",
      },
    },
    secondary: {
      borderRadius: "1rem",
      color: "#121B3F",
      bg: "#f0f0f0",
      transition: ".1s",
      ":hover": { bg: "#f0f0f0" },
      border: "1px solid silver",
      boxShadow: "0 3px silver",
      ":active": {
        boxShadow: "0 0 silver",
        transform: "translateY(3px)",
      },
    },
    deleted: {
      borderRadius: "1rem",
      color: "#121B3F",
      bg: "#ffa9a9",
      transition: ".1s",
      ":hover": { bg: "#ffa9a9" },
      border: "1px solid #CD7777",
      boxShadow: "0 3px #CD7777",
      ":active": {
        boxShadow: "0 0 #CD7777",
        transform: "translateY(3px)",
      },
    },
    added: {
      borderRadius: "1rem",
      color: "#121B3F",
      bg: "#c1f0c8",
      transition: ".1s",
      ":hover": { bg: "#c1f0c8" },
      border: "solid 1px #85BE96",
      boxShadow: "0 3px #85BE96",
      ":active": {
        boxShadow: "0 0 #85BE96",
        transform: "translateY(3px)",
      },
    },
  },
  colors: {
    primary: "#121B3F",
    secondary: "#f0f0f0",
    deleted: "#ffa9a9",
    added: "#c1f0c8",
  },
  fonts: {
    title: "20px",
    main: "16px",
    secondary: "14px",
  },
};

export { design };
