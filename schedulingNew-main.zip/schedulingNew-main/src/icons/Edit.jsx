import * as React from "react";

const Edit = (props) => (
  <svg
    id="editHead"
    fill={props.fill || "white"}
    height={props.size || "24"}
    width={props.size || "24"}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
  >
    <path d="M20.548 3.452a1.54 1.54 0 0 1 0 2.182l-7.636 7.636-3.273 1.091 1.091-3.273 7.636-7.636a1.54 1.54 0 0 1 2.182 0M4 21h15a1 1 0 0 0 1-1v-8a1 1 0 0 0-2 0v7H5V6h7a1 1 0 0 0 0-2H4a1 1 0 0 0-1 1v15a1 1 0 0 0 1 1"></path>
  </svg>
);

export default Edit;
