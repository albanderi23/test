import * as React from "react";

const Trash = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="white"
    width={"24"}
    height={"24"}
    viewBox="0 0 24 24"
  >
    <path d="M22 5a1 1 0 0 1-1 1H3a1 1 0 0 1 0-2h5V3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v1h5a1 1 0 0 1 1 1M4.934 21.071 4 8h16l-.934 13.071a1 1 0 0 1-1 .929H5.931a1 1 0 0 1-.997-.929M15 18a1 1 0 0 0 2 0v-6a1 1 0 0 0-2 0Zm-4 0a1 1 0 0 0 2 0v-6a1 1 0 0 0-2 0Zm-4 0a1 1 0 0 0 2 0v-6a1 1 0 0 0-2 0Z"></path>
  </svg>
);

export default Trash;
