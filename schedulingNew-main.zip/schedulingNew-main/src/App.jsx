import { useEffect, useState } from "react";
import WebContainer from "./components/WebContainer";
import { read, utils, writeFile } from "xlsx";
import XLSX from "xlsx";
import { Input, Table, Tbody, Td, Th, Thead, Tr } from "@chakra-ui/react";
import { design } from "./style/mainStyle";
function App() {
  const [pres, setPres] = useState([]);

  const [uploadedFile, updateUploadedFile] = useState(false);

  const [displayTable, updateDisplayTable] = useState(<></>);

  // useEffect(() => {
  //   if (uploadedFile) {
  //     (async () => {
  //       /* Download from https://docs.sheetjs.com/pres.numbers */
  //       const ab = await uploadedFile.arrayBuffer();
  //       /* parse */
  //       const wb = XLSX.read(ab);

  //       /* generate array of objects from first worksheet */
  //       const ws = wb.Sheets[wb.SheetNames[0]]; // get the first worksheet
  //       const data = utils.sheet_to_json(ws); // generate objects
  //       console.log(data);
  //       /* update state */
  //       setPres(data); // update state
  //       updateDisplayTable(
  //         <Table bg={design.colors.secondary}>
  //           {/* The `thead` section includes the table header row */}
  //           <Thead>
  //             <Tr>
  //               <Th></Th>
  //               <Th textAlign={"center"} colSpan={3} ml={"2px"}>
  //                 {Object.keys(data[0])[0]}
  //               </Th>
  //               <Th></Th>
  //               <Th textAlign={"center"} colSpan={3} ml={"2px"}>
  //                 {Object.keys(data[0])[3]}
  //               </Th>
  //               <Th></Th>
  //               <Th textAlign={"center"} colSpan={3} ml={"2px"}>
  //                 {Object.keys(data[0])[6]}
  //               </Th>
  //               <Th></Th>

  //               <Th textAlign={"center"} colSpan={3} ml={"2px"}>
  //                 {Object.keys(data[0])[9]}
  //               </Th>
  //             </Tr>
  //           </Thead>
  //           {/* The `tbody` section includes the data rows */}
  //           <Tbody>
  //             <Td></Td>
  //             <Td color={"black"}>{Object.values(data[0])[0]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[1]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[2]}</Td>
  //             <Td></Td>
  //             <Td color={"black"}>{Object.values(data[0])[0]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[1]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[2]}</Td>
  //             <Td></Td>
  //             <Td color={"black"}>{Object.values(data[0])[0]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[1]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[2]}</Td>
  //             <Td></Td>
  //             <Td color={"black"}>{Object.values(data[0])[0]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[1]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[2]}</Td>

  //             {/* generate row (TR) for each president */}
  //             {data.map((row, index) =>
  //               index != 0 && index < 9 ? (
  //                 <Tr>
  //                   {/* Generate cell (TD) for name / index */}
  //                   <Td color={"black"}>{Object.values(row)[0]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[1]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[2]}</Td>
  //                   <Td borderLeft={"black solid 1px"} color={"black"}>
  //                     {Object.values(row)[3]}
  //                   </Td>
  //                   <Td color={"black"}>{Object.values(row)[0]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[5]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[6]}</Td>
  //                   <Td borderLeft={"black solid 1px"} color={"black"}>
  //                     {Object.values(row)[7]}
  //                   </Td>
  //                   <Td color={"black"}>{Object.values(row)[0]}</Td>

  //                   <Td color={"black"}>{Object.values(row)[9]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[10]}</Td>
  //                   <Td borderLeft={"black solid 1px"} color={"black"}>
  //                     {Object.values(row)[11]}
  //                   </Td>
  //                   <Td color={"black"}>{Object.values(row)[0]}</Td>

  //                   <Td color={"black"}>{Object.values(row)[13]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[14]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[15]}</Td>
  //                 </Tr>
  //               ) : null
  //             )}
  //             <Tr>
  //               <Th></Th>
  //               <Th textAlign={"center"} colSpan={3} ml={"2px"}>
  //                 {Object.values(data[9])[0]}
  //               </Th>
  //               <Th></Th>

  //               <Th textAlign={"center"} colSpan={3} ml={"2px"}>
  //                 {Object.values(data[9])[1]}
  //               </Th>
  //               <Th></Th>

  //               <Th textAlign={"center"} colSpan={3} ml={"2px"}>
  //                 {Object.values(data[9])[2]}
  //               </Th>
  //               <Th></Th>

  //               <Th textAlign={"center"} colSpan={3} ml={"2px"}>
  //                 {Object.values(data[9])[3]}
  //               </Th>
  //             </Tr>
  //             <Td></Td>
  //             <Td color={"black"}>{Object.values(data[0])[0]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[1]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[2]}</Td>
  //             <Td></Td>
  //             <Td color={"black"}>{Object.values(data[0])[0]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[1]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[2]}</Td>
  //             <Td></Td>
  //             <Td color={"black"}>{Object.values(data[0])[0]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[1]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[2]}</Td>
  //             <Td></Td>
  //             <Td color={"black"}>{Object.values(data[0])[0]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[1]}</Td>
  //             <Td color={"black"}>{Object.values(data[0])[2]}</Td>
  //             {data.map((row, index) =>
  //               index > 10 && index < 18 ? (
  //                 <Tr>
  //                   {/* Generate cell (TD) for name / index */}
  //                   <Td color={"black"}>{Object.values(row)[0]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[1]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[2]}</Td>
  //                   <Td borderLeft={"black solid 1px"} color={"black"}>
  //                     {Object.values(row)[3]}
  //                   </Td>
  //                   <Td color={"black"}>{Object.values(row)[0]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[5]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[6]}</Td>
  //                   <Td borderLeft={"black solid 1px"} color={"black"}>
  //                     {Object.values(row)[7]}
  //                   </Td>
  //                   <Td color={"black"}>{Object.values(row)[0]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[9]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[10]}</Td>
  //                   <Td borderLeft={"black solid 1px"} color={"black"}>
  //                     {Object.values(row)[11]}
  //                   </Td>
  //                   <Td color={"black"}>{Object.values(row)[0]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[13]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[14]}</Td>
  //                   <Td color={"black"}>{Object.values(row)[15]}</Td>
  //                 </Tr>
  //               ) : null
  //             )}
  //           </Tbody>
  //         </Table>
  //       );
  //     })();
  //   }
  // }, [uploadedFile]);
  return (
    <>
      {/* <Input
        type="file"
        onChange={(e) => {
          updateUploadedFile(e.target.files[0]);
        }}
      />
      {displayTable} */}
      <WebContainer />
    </>
  );
}

export default App;
