import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import { Provider } from "react-redux";
import { ChakraProvider, extendTheme } from "@chakra-ui/react";
import store from "./store.js";

createRoot(document.getElementById("root")).render(
  <ChakraProvider theme={extendTheme({ direction: "rtl" })}>
    <Provider store={store}>
      <App />
    </Provider>
  </ChakraProvider>
);
