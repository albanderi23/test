import {
  Alert,
  AlertDescription,
  AlertIcon,
  Flex,
  Text,
} from "@chakra-ui/react";
import React from "react";
import Loading from "../components/Loading";
import { design } from "../style/mainStyle";

export default function AlertingMessage(params) {
  const type = params.type ? params.type : "error";
  switch (type) {
    case "loading":
      return (
        <Flex
          borderRadius={"1rem"}
          color={"black"}
          fontSize={"20px"}
          overflow={"hidden"}
          w={"fit-content"}
        >
          <Alert status="loading">
            <AlertDescription>
              <Flex
                color={"black"}
                width={"fit-content"}
                alignItems={"center"}
                gap={"10px"}
              >
                <Loading h={"2rem"} />
                <Text fontSize={"20px"}>{params.message}</Text>
              </Flex>
            </AlertDescription>
          </Alert>
        </Flex>
      );
    case "warning":
      return (
        <Flex
          borderRadius={"1rem"}
          color={"black"}
          fontSize={"20px"}
          overflow={"hidden"}
          w={"fit-content"}
        >
          <Alert status="warning">
            <AlertIcon />
            <AlertDescription sx={{ textWrap: "wrap" }}>
              {params.message}
            </AlertDescription>
          </Alert>
        </Flex>
      );
    case "success":
      return (
        <Flex w={"fit-content"} borderRadius={"1rem"} overflow={"hidden"}>
          <Alert status="success">
            <AlertIcon />
            <AlertDescription sx={{ textWrap: "wrap" }}>
              <Flex color={"black"} gap={"10px"} alignItems={"center"}>
                <Text>{params.message}</Text>
              </Flex>
            </AlertDescription>
          </Alert>
        </Flex>
      );
    default:
      return (
        <Flex w={"fit-content"} borderRadius={"1rem"} overflow={"hidden"}>
          <Alert status="error">
            <AlertIcon />
            <AlertDescription sx={{ textWrap: "wrap" }}>
              <Flex color={"black"}>{params.message}</Flex>
            </AlertDescription>
          </Alert>
        </Flex>
      );
  }
}
