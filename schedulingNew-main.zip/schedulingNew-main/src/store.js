import { configureStore } from "@reduxjs/toolkit";
import teachersSlice from "./components/TeachersTables/TeachersSlice";
import ClassesSlice from "./components/Classes/ClassesSlice";
import DiplomasSlice from "./components/DiplomaTables/DiplomasSlice";
import GroupsSlice from "./components/groupsTables/groupsSlice";
import onlineSlice from "./components/OnlineDepartment/onlineSlice";
import loginSlice from "./login/loginSlice";
export default configureStore({
  reducer: {
    teachers: teachersSlice,
    classes: ClassesSlice,
    diplomas: DiplomasSlice,
    groups: GroupsSlice,
    online: onlineSlice,
    login: loginSlice,
  },
});
