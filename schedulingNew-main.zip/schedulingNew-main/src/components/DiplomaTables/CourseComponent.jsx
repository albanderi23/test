import {
  Card,
  CardBody,
  CardHeader,
  Container,
  Flex,
  Input,
  Text,
} from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import { design } from "../../style/mainStyle";
import PC from "../../../public/PC";
import Board from "../../../public/Board";
import Internet from "../../../public/Internet";
import "./courseComponent.css";
import { AutoTextSize } from "auto-text-size";
import { useDispatch, useSelector } from "react-redux";
import { editCourseHours, editCourseType } from "./DiplomasSlice";

export default function CourseComponent(params) {
  const courseData = useSelector(
    (state) =>
      state.diplomas.value[params.diploma][params.level][params.courseName]
  );
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(
      editCourseHours({
        name: params.diploma,
        level: params.level,
        courseName: params.courseName,
        newHours: courseData.hours,
        newType: courseData.type,
      })
    );
  }, []);

  const [formChange, setFormChange] = useState({
    hours: "white",
    type: "silver",
    lab: "transparent",
    theory: "transparent",
    online: "transparent",
  });
  //   const updateCourseData = params.updateCourseData;
  //   const courseData = params.CardourseData;
  useEffect(() => {
    if (courseData.newHours != courseData.hours) {
      setFormChange({ ...formChange, hours: "#c1f0c8" });
    } else {
      setFormChange({ ...formChange, hours: "white" });
    }
  }, [courseData.hours, courseData.newHours]);

  useEffect(() => {
    if (courseData.type != courseData.newType && courseData.newType) {
      setFormChange({
        ...formChange,
        type: design.colors.deleted,
        lab: courseData.type == "Lab" ? "#c1f0c8" : "transparent",
        theory: courseData.type == "Theory" ? "#c1f0c8" : "transparent",
        online: courseData.type == "Online" ? "#c1f0c8" : "transparent",
      });
    } else {
      setFormChange({
        ...formChange,
        type: "silver",
        lab: courseData.type == "Lab" ? "#c1f0c8" : "transparent",
        theory: courseData.type == "Theory" ? "#c1f0c8" : "transparent",
        online: courseData.type == "Online" ? "#c1f0c8" : "transparent",
      });
    }
  }, [courseData.type, courseData.newType]);

  //this will create buttons for course type
  const courseTypeOptions = [
    [<PC size={"3rem"} color={design.colors.primary} />, "Lab", "معمل"],
    [<Board size={"3rem"} color={design.colors.primary} />, "Theory", "نظري"],
    [
      <Internet size={"3rem"} color={design.colors.primary} />,
      "Online",
      "عن بعد",
    ],
  ].map((type, index) => {
    return (
      <Container
        transition={".3s"}
        display={"flex"}
        flexDir={"column"}
        alignItems={"center"}
        justifyContent={"center"}
        borderRadius={"1rem"}
        sx={{ cursor: "pointer" }}
        boxShadow={"0 5px #f0f0f0"}
        border={`#d0d0d0 solid 1px`}
        bg={
          courseData.type == type[1]
            ? formChange.type
            : courseData.newType == type[1]
            ? "#c1f0c8"
            : formChange[type[1]]
        }
        p={".5rem"}
        key={index}
        onClick={(e) => {
          dispatch(
            editCourseType({
              name: params.diploma,
              level: params.level,
              courseName: params.courseName,
              newType: type[1],
            })
          );
        }}
      >
        {type[0]}
        <Text>{type[2]}</Text>
      </Container>
    );
  });
  //course data contains: {name,hours,type}
  return (
    <Card
      w={"19rem"}
      fontSize={"20px"}
      overflow={"hidden"}
      border={`2px silver solid`}
      boxShadow={"0 3px 5px silver"}
    >
      <CardHeader
        display={"flex"}
        justifyContent={"center"}
        bg={design.colors.primary}
        color={design.colors.secondary}
      >
        <AutoTextSize mode="oneline" maxFontSizePx={23}>
          {courseData.name}
        </AutoTextSize>
      </CardHeader>
      <CardBody
        display={"flex"}
        p={params.height}
        flexDir={"column"}
        gap={"1rem"}
      >
        <Flex flexDir={"column"}>
          <Text>ساعات المادة:</Text>
          <Input
            type="number"
            value={courseData.newHours || ""}
            boxShadow={"inner"}
            bg={formChange.hours}
            onChange={(e) => {
              dispatch(
                editCourseHours({
                  name: params.diploma,
                  level: params.level,
                  courseName: params.courseName,
                  newHours: e.target.value,
                })
              );
            }}
          />
        </Flex>
        <Flex flexDir={"column"}>
          <Text>نوع المادة:</Text>
          <Flex gap={"5px"}>{courseTypeOptions}</Flex>
        </Flex>
      </CardBody>
    </Card>
  );
}
