import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: {},
  diplomas: {},
};

const DiplomasSlice = createSlice({
  name: "diplomas",
  initialState,
  reducers: {
    addDiploma: (state, action) => {
      state.value = action.payload;
    },
    normalizeCourses: (state, action) => {
      state.value[action.payload.diplomaName][action.payload.level] =
        Object.keys(
          state.value[action.payload.diplomaName][action.payload.level]
        ).reduce((coursesList, courseName) => {
          return {
            ...coursesList,
            [courseName]: {
              ...state.value[action.payload.diplomaName][action.payload.level][
                courseName
              ],
              hours:
                state.value[action.payload.diplomaName][action.payload.level][
                  courseName
                ].newHours ||
                state.value[action.payload.diplomaName][action.payload.level][
                  courseName
                ].hours,
              newHours:
                state.value[action.payload.diplomaName][action.payload.level][
                  courseName
                ].newHours ||
                state.value[action.payload.diplomaName][action.payload.level][
                  courseName
                ].hours,
              type:
                state.value[action.payload.diplomaName][action.payload.level][
                  courseName
                ].newType ||
                state.value[action.payload.diplomaName][action.payload.level][
                  courseName
                ].type,
              newType:
                state.value[action.payload.diplomaName][action.payload.level][
                  courseName
                ].newType ||
                state.value[action.payload.diplomaName][action.payload.level][
                  courseName
                ].type,
            },
          };
        }, {});
    },
    editCourseHours: (state, action) => {
      state.value[action.payload.name][action.payload.level][
        action.payload.courseName
      ] = {
        ...state.value[action.payload.name][action.payload.level][
          action.payload.courseName
        ],
        newHours: action.payload.newHours,
      };
    },
    editCourseType: (state, action) => {
      state.value[action.payload.name][action.payload.level][
        action.payload.courseName
      ] = {
        ...state.value[action.payload.name][action.payload.level][
          action.payload.courseName
        ],
        newType: action.payload.newType,
      };
    },
  },
});

export const { addDiploma, editCourseHours, editCourseType, normalizeCourses } =
  DiplomasSlice.actions;
export default DiplomasSlice.reducer;
