import {
  Alert,
  AlertDescription,
  AlertIcon,
  Button,
  Flex,
  Select,
  Text,
} from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import CourseComponent from "./CourseComponent";
import { design } from "../../style/mainStyle";
import Loading from "../Loading";
import api from "../../api/api";
import { useDispatch, useSelector } from "react-redux";
import { normalizeCourses } from "./DiplomasSlice";

export default function CoursesContainer(params) {
  const courses = params.courses;
  const dispatch = useDispatch();
  const coursesData = useSelector(
    (state) => state.diplomas.value[params.diploma][params.level]
  );
  const loginData = useSelector((state) => state.login.value);
  const [coursesUpdate, setCoursesUpdate] = useState({ level: params.level });
  const [triggerCourseUpdate, setDataToTrigger] = useState({});
  const [changeTrigger, setChangeTrigger] = useState(1);
  const [message, displayMessage] = useState("");

  useEffect(() => {
    if (triggerCourseUpdate["name"]) {
      setCoursesUpdate({
        ...coursesUpdate,
        [triggerCourseUpdate["name"]]: {
          hours: triggerCourseUpdate["hours"],
          type: triggerCourseUpdate["type"],
        },
      });
    }
  }, [triggerCourseUpdate]);
  const buildCourses = (diplomaLevel, diploma) => {
    return Object.keys(diplomaLevel).map((course) => {
      return (
        <Flex
          key={course + changeTrigger}
          m={0}
          placeSelf={"center"}
          justifyContent={"center"}
          maxW={"450px"}
          bg={design.colors.secondary}
        >
          <CourseComponent
            courseName={course}
            course={diplomaLevel[course]}
            diploma={diploma}
            level={params.level}
            height={params.height}
            update={setDataToTrigger}
          />
        </Flex>
      );
    });
  };
  const [coursesDisplay, updateCoursesDisplay] = useState(
    buildCourses(courses, params.diploma)
  );

  const saveChanges = async () => {
    try {
      displayMessage(
        <Alert status="loading">
          <AlertDescription>
            <Flex width={"fit-content"} alignItems={"center"} gap={"10px"}>
              <Loading h={"2rem"} />
              <Text fontSize={"20px"}>جاري الحفظ</Text>
            </Flex>
          </AlertDescription>
        </Alert>
      );
      await api
        .post("api.php?action=subjects", {
          level: params.level,
          courseUpdates: Object.values(coursesData).reduce(
            (courses, course) => {
              return { ...courses, [course.subject_id]: { ...course } };
            },
            {}
          ),
          diploma: params.diplomaID,
          branch: loginData.branch_id,
        })
        .then((respond) => {
          setChangeTrigger(changeTrigger + 1);
          displayMessage(
            <Alert status="success">
              <AlertIcon />
              <AlertDescription sx={{ textWrap: "wrap" }}>
                <Flex gap={"10px"} alignItems={"center"}>
                  <Text>تم حفظ التغييرات</Text>
                </Flex>
              </AlertDescription>
            </Alert>
          );
        })
        .then(() => {
          dispatch(
            normalizeCourses({
              diplomaName: params.diploma,
              level: params.level,
            })
          );
        })
        .catch((e) => {
          displayMessage(
            <Alert status="error">
              <AlertIcon />
              <AlertDescription sx={{ textWrap: "wrap" }}>
                لم نتمكن من حفظ المواد
              </AlertDescription>
            </Alert>
          );
        });
    } catch (e) {
      displayMessage(
        <Alert status="error">
          <AlertIcon />
          <AlertDescription sx={{ textWrap: "wrap" }}>
            حدث خطا اثناء توصيل الخادم
          </AlertDescription>
        </Alert>
      );
    }
  };

  return (
    <Flex w={"100%"} flexDir={"column"} gap={"1rem"}>
      <Flex
        color={"black"}
        mx={"auto"}
        overflow={"hidden"}
        borderRadius={"1rem"}
      >
        {message}
      </Flex>
      <Flex w={"fit-content"} mx={"auto"} gap={"10px"} flexWrap={"wrap"}>
        {coursesDisplay}
      </Flex>
      <Button
        mx={"auto"}
        w={"fit-content"}
        sx={design.button.added}
        onClick={() => {
          saveChanges();
        }}
      >
        حفظ
      </Button>
    </Flex>
  );
}
