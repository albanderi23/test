import { border, Button, Flex, Grid, Heading, Select } from "@chakra-ui/react";
import { AutoTextSize } from "auto-text-size";
import React, { useEffect, useState } from "react";
import LevelsContainer from "./LevelsContainer";
import Loading from "../Loading";
import { design } from "../../style/mainStyle";
import { useDispatch, useSelector } from "react-redux";
import { addDiploma } from "./DiplomasSlice";
import api from "../../api/api";

export default function DiplomasContainer() {
  const [diplomas, setDiplomas] = useState([]);
  const loginData = useSelector((state) => state.login);
  useEffect(() => {
    const runAPI = async () => {
      const request = await api
        .get("api.php?action=diplomas", {
          params: {
            branch: loginData.branch_id,
          },
        })
        .then((data) => data.data)
        .then((diplomasData) => {
          setDiplomas(diplomasData);
        });
    };
    runAPI();
  }, []);

  const dispatch = useDispatch();
  const selector = useSelector((state) => state.diplomas.value);

  const [currentDiploma, changeDiploma] = useState(0);
  const [displayDiploma, changeDisplayDiploma] = useState(<></>);

  useEffect(() => {
    if (currentDiploma) {
      const apiCall = async () => {
        await api
          .get("api.php?action=subjects", {
            params: {
              branch: loginData.value.branch_id,
              diploma: currentDiploma,
            },
          })
          .then((data) => data.data)
          .then((data) => {
            dispatch(addDiploma(data));
            return Object.keys(data)[0];
          })
          .then((selectedDiploma) => {
            changeDisplayDiploma(
              <LevelsContainer
                key={selectedDiploma}
                diploma={selectedDiploma}
                diplomaID={currentDiploma}
              />
            );
          });
      };
      apiCall();
    }
  }, [currentDiploma]);
  const detailsDesign = {
    border: "solid 1px silver",
    w: "100%",
    justifyContent: "center",
  };
  return (
    <Flex width={"100%"} flexDir={"column"}>
      <Flex alignItems={"flex-end"}>
        <Heading
          display={"flex"}
          flexDir={"row"}
          gap={"10px"}
          pt={"1rem"}
          px={"2rem"}
        >
          دبلوم{" "}
        </Heading>
        <Select
          sx={design.select}
          color={"black"}
          w={"fit-content"}
          value={currentDiploma}
          placeholder="الدبلومات"
          onChange={(e) => {
            changeDiploma(e.target.value);
          }}
        >
          {diplomas.map((diploma) => {
            return (
              <option value={diploma.id} key={diploma.id}>
                {diploma.name}
              </option>
            );
          })}
        </Select>
      </Flex>
      {displayDiploma}
    </Flex>
  );
}
