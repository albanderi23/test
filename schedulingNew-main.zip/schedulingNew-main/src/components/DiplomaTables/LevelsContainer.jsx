import { Button, Container, Flex, Heading, Text } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import CoursesContainer from "./CoursesContainer";
import OpenEye from "../../../public/OpenEye";
import ClosedEye from "../../../public/ClosedEye";
import { design } from "../../style/mainStyle";
import Hours from "../../../public/Hours";
import Edit from "../../../public/Edit";
import { useSelector } from "react-redux";

export default function LevelsContainer(params) {
  const levels = useSelector((state) => state.diplomas.value[params.diploma]);
  const data = useSelector((state) => state.diplomas.value);
  return (
    <Flex w={"100%"} flexDir={"column"} gap={"3rem"} padding={"1rem"}>
      {Object.keys(levels || {}).map((level) => {
        return (
          <Flex
            gap={"1rem"}
            width={"100%"}
            flexDir={"column"}
            key={level}
            transition={".3s"}
            overflow={"hidden"}
            bg={design.colors.secondary}
            p={"1rem"}
            borderRadius={"1rem"}
            alignSelf={"center"}
          >
            <Flex mx={"auto"} justifyContent={"center"} width={"fit-content"}>
              <Heading
                textAlign={"center"}
                color={design.colors.primary}
                fontFamily={"GE-SS-Two-Bold"}
                size={"lg"}
                sx={{ textWrap: "noWrap" }}
              >{`المستوى ${level}`}</Heading>
            </Flex>
            <Flex>
              <CoursesContainer
                diploma={params.diploma}
                diplomaID={params.diplomaID}
                courses={levels[level]}
                level={level}
              />
            </Flex>
          </Flex>
        );
      })}
    </Flex>
  );
}
