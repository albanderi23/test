import {
  Alert,
  AlertDescription,
  AlertIcon,
  Button,
  Flex,
  Grid,
  Select,
  Table,
  Text,
  Toast,
} from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import { design } from "../../style/mainStyle";
import GroupsTable from "./GroupsTable";
import { diplomasNames } from "../../assets/PrePrepared";
import api from "../../api/api";
import Loading from "../Loading";
import { useDispatch, useSelector } from "react-redux";
import { editGroup, addTable, deleteTable } from "./groupsSlice";

export default function GroupsContainer() {
  const [diplomasOption, setDiplomasOption] = useState([]);
  const [diplomasData, setDiplomasData] = useState({});
  useEffect(() => {
    try {
      api
        .get("api.php?action=diplomas")
        .then((data) => data.data)
        .then((data) => {
          setDiplomasData(data);
          setDiplomasOption(Object.values(data).map((diploma) => diploma.name));
        });
    } catch (e) {
      console.log(e);
    }
  }, []);
  const loginData = useSelector((state) => state.login.value);
  const diplomasInfo = useDispatch();
  const diplomasList = useSelector((state) => state.groups.value);
  useEffect(() => {
    try {
      api
        .get("api.php?action=groups", {
          params: {
            branch: loginData.branch_id,
          },
        })
        .then((data) => data.data)
        .then((data) => {
          console.log(data);
          Object.keys(data).forEach((group) => {
            diplomasInfo(
              addTable({
                ...data[group],
                name: group,
                isNew: false,
                table: {
                  morning: data[group].table.morning || [
                    0, 0, 0, 0, 0, 0, 0, 0,
                  ],
                  afternoon: data[group].table.afternoon || [
                    0, 0, 0, 0, 0, 0, 0, 0,
                  ],
                  evening: data[group].table.evening || [
                    0, 0, 0, 0, 0, 0, 0, 0,
                  ],
                },
              })
            );
          });
        });
    } catch (e) {
      console.log(e);
    }
  }, []);
  const [diplomasTables, addDiplomaTable] = useState([]);
  const [selectedDiploma, updateSelectedDiploma] = useState(diplomasOption[0]);
  const [err, setErr] = useState("");

  const checkList = (selectedDiploma) => {
    return (
      Object.keys(diplomasList).filter((diploma) => diploma == selectedDiploma)
        .length > 0
    );
  };

  const addDiploma = async () => {
    if (!checkList(selectedDiploma)) {
      try {
        setErr(
          <Alert status="loading">
            <AlertDescription>
              <Flex width={"fit-content"} alignItems={"center"} gap={"10px"}>
                <Loading h={"2rem"} />
                <Text fontSize={"20px"}> جاري التحميل</Text>
              </Flex>
            </AlertDescription>
          </Alert>
        );
        diplomasInfo(addTable({ name: selectedDiploma, isNew: true }));
        setErr("");
      } catch (e) {
        setErr(
          <Flex
            borderRadius={"1rem"}
            color={"black"}
            fontSize={"20px"}
            overflow={"hidden"}
          >
            <Alert status="error">
              <AlertIcon />
              <AlertDescription sx={{ textWrap: "wrap" }}>
                حدث خطا اثناء توصيل الخادم
              </AlertDescription>
            </Alert>
          </Flex>
        );
      }
    } else {
      setErr(
        <Flex
          borderRadius={"1rem"}
          color={"black"}
          fontSize={"20px"}
          overflow={"hidden"}
        >
          <Alert status="warning">
            <AlertIcon />
            <AlertDescription sx={{ textWrap: "wrap" }}>
              الشعبة موجودة بالفعل
            </AlertDescription>
          </Alert>
        </Flex>
      );
    }
  };

  useEffect(() => {
    addDiplomaTable(
      <>
        {Object.keys(diplomasList).map((diploma) => {
          return (
            <GroupsTable
              key={diploma}
              name={diploma}
              groupLevels={diplomasList}
              deleteDiploma={addDiplomaTable}
            />
          );
        })}
      </>
    );
  }, [diplomasList]);

  const saveChanges = async () => {
    try {
      setErr(
        <Flex
          borderRadius={"1rem"}
          color={"black"}
          fontSize={"20px"}
          overflow={"hidden"}
        >
          <Alert status="loading">
            <AlertDescription sx={{ textWrap: "wrap" }}>
              <Flex gap={"10px"} alignItems={"center"}>
                <Loading h={"2rem"} />
                <Text>جاري التحديث...</Text>
              </Flex>
            </AlertDescription>
          </Alert>
        </Flex>
      );
      console.log(diplomasList);
      const requestData = {
        branch: loginData.branch_id,
        groupUpdates: Object.keys(diplomasList).reduce(
          (diplomas, currentDiploma) => {
            console.log(
              diplomasData.filter((diploma) => diploma.name == currentDiploma)
            );
            return {
              ...diplomas,
              [currentDiploma]: {
                ...diplomasList[currentDiploma],
                diploma_id: diplomasData.filter(
                  (diploma) => diploma.name == currentDiploma
                )[0].id,
              },
            };
          },
          {}
        ),
      };
      const request = await api.post("api.php?action=groups", {
        ...requestData,
      });
      console.log(request);
      setErr(
        <Flex
          borderRadius={"1rem"}
          color={"black"}
          fontSize={"20px"}
          overflow={"hidden"}
        >
          <Alert status="success">
            <AlertIcon />
            <AlertDescription sx={{ textWrap: "wrap" }}>
              <Flex gap={"10px"} alignItems={"center"}>
                <Text>تم تحديث الشعب</Text>
              </Flex>
            </AlertDescription>
          </Alert>
        </Flex>
      );
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <Flex
      alignItems={"center"}
      gap={"10px"}
      w={"80%"}
      bg={design.colors.secondary}
      p={"1rem"}
      minH={"90%"}
      borderRadius={"1rem"}
      flexDir={"column"}
    >
      <Flex width={"fit-content"} gap={"10px"}>
        <Select
          defaultValue={"أمن سيبراني"}
          sx={design.select}
          onChange={(e) => {
            updateSelectedDiploma(e.target.value);
          }}
        >
          {diplomasOption.map((diploma) => {
            return (
              <option key={diploma} value={diploma}>
                {diploma}
              </option>
            );
          })}
        </Select>
        <Button
          sx={design.button.secondary}
          onClick={() => {
            addDiploma();
          }}
        >
          إضافة
        </Button>
      </Flex>
      {err}
      <Grid
        templateColumns={"auto auto auto"}
        gap={"20px"}
        id="tablesContainer"
      >
        {diplomasTables}
      </Grid>
      <Button
        sx={design.button.secondary}
        mt={"auto"}
        onClick={() => {
          saveChanges();
        }}
      >
        حفظ التغييرات
      </Button>
    </Flex>
  );
}
