import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: {},
};

const groupsSlice = createSlice({
  name: "groups",
  initialState,
  reducers: {
    upgrading: (state, action) => {
      console.log(action.payload.name);
      state.value[action.payload.name] = {
        ...state.value[action.payload.name],
        table: {
          morning: state.value[action.payload.name].table.morning.map(
            (_, index) => {
              return index == 0
                ? 0
                : state.value[action.payload.name].table.morning[index - 1];
            }
          ),
          afternoon: state.value[action.payload.name].table.afternoon.map(
            (_, index) => {
              return index == 0
                ? 0
                : state.value[action.payload.name].table.afternoon[index - 1];
            }
          ),
          evening: state.value[action.payload.name].table.evening.map(
            (_, index) => {
              return index == 0
                ? 0
                : state.value[action.payload.name].table.evening[index - 1];
            }
          ),
        },
      };
    },
    addTable: (state, action) => {
      state.value = {
        ...state.value,
        [action.payload.name]: {
          groupName: action.payload.name,
          groupID: action.payload.groupID,
          isNew: action.payload.isNew,
          table: action.payload.table
            ? action.payload.table
            : {
                morning: [0, 0, 0, 0, 0, 0, 0, 0],
                afternoon: [0, 0, 0, 0, 0, 0, 0, 0],
                evening: [0, 0, 0, 0, 0, 0, 0, 0],
              },
        },
      };
    },
    levelUpAll: (state, action) => {
      Object.keys(state.value)
        .map((group) => state.value[group])
        .map((group) => {
          return {
            ...group,
            table: {
              morning: group.table.morning.map((current, index) => {
                if (index == 0) {
                  return 0;
                }
                return group.table.morning[index - 1];
              }),
              afternoon: group.table.afternoon.map((current, index) => {
                if (index == 0) {
                  return 0;
                }
                return group.table.afternoon[index - 1];
              }),
              evening: group.table.evening.map((current, index) => {
                if (index == 0) {
                  return 0;
                }
                return group.table.evening[index - 1];
              }),
            },
          };
        })
        .forEach((group) => {
          state.value[group] = group;
        });
    },
    editGroup: (state, action) => {
      state.value[action.payload.name].table[action.payload.period][
        action.payload.level
      ] = action.payload.count;
    },
    deleteTable: (state, action) => {
      delete state.value[action.payload.name];
    },
  },
});

export const { addTable, upgrading, editGroup, deleteTable, levelUpAll } =
  groupsSlice.actions;
export default groupsSlice.reducer;
