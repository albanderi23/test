import { Container, Flex, Grid, Input } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import { design } from "../../style/mainStyle";
import "./GroupsTable.css";
import { useDispatch, useSelector } from "react-redux";
import { deleteTable, editGroup, upgrading } from "./groupsSlice";

export default function GroupsTable(params) {
  const name = params.name;
  const isNew = useSelector((state) => state.groups.value[name].isNew);
  console.log(`${params.name} ${isNew}`);
  const groupLevels = useSelector((state) => state.groups.value[name].table);
  const groupsEdit = useDispatch();
  const updateGroupLevels = params.updateGroupLevels;
  var updateGroups = { ...groupLevels };
  const groupDecision = () => {
    switch (name) {
      case "الأمن سيبراني":
      case "الذكاء الاصطناعي":
      case "إدارة الفنادق والمنتجعات السياحية":
      case "التسويق والتجارة الإلكترونية":
        return "table_blue";
      case "موارد بشرية":
      case "إدارة الأعمال":
      case " التأمين وإدارة المخاطر":
      case "العلاقات العامة والإعلام":
        return "table_green";
      default:
        return "table_orange";
    }
  };

  const inputStyle = {
    bg: "white",
    w: "100%",
    border: "solid transparent 0px",
    textAlign: "center",
    p: 0,
    height: "auto",
    type: "number",
    borderRadius: 0,
    boxShadow: "inner",
  };

  const groupsTable = (
    <React.Fragment>
      <Grid
        borderRadius={"1rem"}
        overflow={"hidden"}
        width={"fit-content"}
        bg={"black"}
        gap={"1px"}
        border={"1px solid black"}
        gridTemplateColumns={"repeat(4,1fr)"}
        gridTemplateRows={"auto-fill"}
        className={`table ${groupDecision()}`}
        alignContent={"center"}
        boxShadow={"0 3px 5px silver"}
        color={design.colors.primary}
      >
        <Flex
          gridRowStart={"span 2"}
          bg={isNew ? design.colors.deleted : design.colors.added}
          cursor={"pointer"}
          onClick={() => {
            if (isNew) {
              params.deleteDiploma([]);
              groupsEdit(deleteTable({ name: name }));
            } else {
              groupsEdit(upgrading({ name: name }));
            }
          }}
        >
          {isNew ? "ازالة" : "ترفيع"}
        </Flex>
        <Flex gridColumnStart={"span 3"}>{name}</Flex>
        <Flex>صباح</Flex>
        <Flex>ظهر</Flex>
        <Flex>مساء</Flex>
        {[...Array(8)].map((value, index) => {
          return (
            <React.Fragment key={index}>
              <Container bg={"silver"}>مستوى {index + 1}</Container>
              {/*------صباح------*/}
              <Input
                sx={inputStyle}
                value={groupLevels["morning"][index]}
                type="number"
                onClick={(e) => {
                  e.target.select();
                }}
                onChange={(e) => {
                  groupsEdit(
                    editGroup({
                      name: name,
                      level: index,
                      period: "morning",
                      count:
                        e.target.value == "" ? 0 : parseInt(e.target.value),
                    })
                  );
                }}
                min={0}
              ></Input>
              {/*------ظهر------*/}

              <Input
                sx={inputStyle}
                value={groupLevels["afternoon"][index]}
                type="number"
                onClick={(e) => {
                  e.target.select();
                }}
                onChange={(e) => {
                  groupsEdit(
                    editGroup({
                      name: name,
                      level: index,
                      period: "afternoon",
                      count:
                        e.target.value == "" ? 0 : parseInt(e.target.value),
                    })
                  );
                }}
                min={0}
              ></Input>
              {/*------مساء------*/}

              <Input
                sx={inputStyle}
                placeholder="0"
                onClick={(e) => {
                  e.target.select();
                }}
                type="number"
                value={groupLevels["evening"][index]}
                onChange={(e) => {
                  groupsEdit(
                    editGroup({
                      name: name,
                      level: index,
                      period: "evening",
                      count:
                        e.target.value == "" ? 0 : parseInt(e.target.value),
                    })
                  );
                }}
                min={0}
              ></Input>
            </React.Fragment>
          );
        })}
      </Grid>
    </React.Fragment>
  );
  return groupsTable;
}
