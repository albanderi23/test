import { Button, Flex, textDecoration } from "@chakra-ui/react";

import React, { useEffect, useState } from "react";
import "./scheduleDesign.css";
import TeacherTablesContainer from "./TeacherTablesContainer";
import GroupsTableCountainer from "./GroupsTableCountainer";
import { design } from "../../style/mainStyle";
import BranchMasterTable from "./BranchMasterTable";

export default function ScheduleTablesContainer() {
  const tables = {
    الفرع: <BranchMasterTable />,
    المعلمين: <TeacherTablesContainer />,
    الشعب: <GroupsTableCountainer />,
  };

  const buildOptions = () => {
    return Object.keys(tables).map((table) => {
      return (
        <Button
          key={table}
          border={"1px silver solid"}
          flexGrow={1}
          borderRadius={"0"}
          bg={selected == table ? "#d0d0d0" : "#f0f0f0"}
          boxShadow={
            selected == table ? "inset 0 5px 10px 0 silver" : undefined
          }
          sx={{
            ":hover": {
              bg: "silver",
            },
          }}
          onClick={(e) => {
            updateSelected(table);
          }}
        >
          {table}
        </Button>
      );
    });
  };

  const [selected, updateSelected] = useState(Object.keys(tables)[0]);
  const [currentTable, selectTable] = useState(tables[selected]);
  const [tablesOptions, updateTablesOptions] = useState(buildOptions);

  useEffect(() => {
    selectTable(tables[selected]);
  }, [selected]);

  useEffect(() => {
    updateTablesOptions(buildOptions);
  }, [currentTable]);

  return (
    <Flex w={"100%"} alignItems={"center"} flexDir={"column"} mb={"0.5rem"}>
      <Flex w={"70%"} borderRadius={"1rem 1rem 0 0"} overflow={"hidden"}>
        {tablesOptions}
      </Flex>
      <Flex
        bg={design.colors.secondary}
        borderRadius={"1rem"}
        color={"black"}
        p={".5rem"}
      >
        {currentTable}
      </Flex>
    </Flex>
  );
}
