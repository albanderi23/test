import { Flex, Grid, Heading, Text } from "@chakra-ui/react";
import React, { useState } from "react";
import { days, periods } from "../helpfulElements/Timing";
import { design } from "../../style/mainStyle";
import "./teacherTableComponent.css";
import { AutoTextSize } from "auto-text-size";

export default function TeacherTableComponent(params) {
  return (
    <Flex
      p={"1rem"}
      gap={"1rem"}
      width={"100%"}
      flexDir={"column"}
      alignItems={"center"}
    >
      <Grid
        className="grid-container"
        w={"100%"}
        textAlign={"center"}
        templateColumns={"10% repeat(6,15%)"}
        borderRadius={"1rem"}
        overflow={"hidden"}
        bg={"black"}
        gap={"1px"}
        border={"solid black 1px"}
        shadow={"0 3px 5px 0 silver"}
      >
        {[`${params.hours} ساعة`, ...periods].map((period) => (
          <Flex justifyContent={"center"} key={period} alignItems={"center"}>
            <Text>{period}</Text>
          </Flex>
        ))}
        {days.map((day) => (
          <React.Fragment key={day}>
            <Flex
              height={"100%"}
              alignItems={"center"}
              justifyContent={"center"}
            >
              {day}
            </Flex>
            {params.courses[day].map((course, index) => (
              <Flex
                justifyContent={"center"}
                minH={"7rem"}
                py={"10px"}
                flexDir={"column"}
                key={index}
              >
                {course.length == 0 ? (
                  <Flex></Flex>
                ) : (
                  <>
                    <Flex justifyContent={"center"} px={"10px"}>
                      <AutoTextSize maxFontSizePx={16} minFontSizePx={14}>
                        {course[0]}
                      </AutoTextSize>
                    </Flex>
                    <Flex justifyContent={"center"} px={"10px"}>
                      <AutoTextSize maxFontSizePx={16} minFontSizePx={14}>
                        {course[1]}
                      </AutoTextSize>
                    </Flex>
                    <Text>{course[2]}</Text>
                  </>
                )}
              </Flex>
            ))}
          </React.Fragment>
        ))}
      </Grid>
    </Flex>
  );
}
