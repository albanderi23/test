import {
  Alert,
  AlertDescription,
  AlertIcon,
  Button,
  Flex,
  Heading,
  Select,
  Text,
} from "@chakra-ui/react";
import React, { Suspense, useEffect, useState } from "react";
import { design } from "../../style/mainStyle";
import TeacherTableComponent from "./TeacherTableComponent";
import Loading from "../Loading";
import Teachers from "../TeachersTables/Teachers";
import api from "../../api/api";

export default function TeacherTablesContainer() {
  const empty = {
    الاحد: [[], [], [], [], [], []],
    الاثنين: [[], [], [], [], [], []],
    الثلاثاء: [[], [], [], [], [], []],
    الاربعاء: [[], [], [], [], [], []],
    الخميس: [[], [], [], [], [], []],
  };

  const [teacherTable, changeTeacherTable] = useState(<></>);

  const getTeacherTable = async (teacher) => {
    changeTeacherTable(<Loading h={"30rem"} />);
    await api(`teachers`)
      .then((res) => res.data[teacher])
      .then((data) =>
        changeTeacherTable(
          <TeacherTableComponent
            name={teacher}
            hours={data.hours}
            courses={data.courses}
          />
        )
      )
      .catch((e) => {
        changeTeacherTable(
          <>
            <Flex borderRadius={"1rem"} overflow={"hidden"}>
              <Alert status="error">
                <AlertIcon />
                <AlertDescription>
                  يبدو اننا لم نستطع الوصول الى جدول المعلم.
                </AlertDescription>
              </Alert>
            </Flex>
            <TeacherTableComponent name={""} courses={empty} hours={"0"} />
          </>
        );
      });
  };

  const [teachersList, updateTeachersList] = useState(
    <Flex w={"100%"} justifyContent={"center"} flexDir={"column"}>
      <Flex
        w={"20%"}
        justifyContent={"center"}
        alignSelf={"center"}
        borderRadius={"1rem"}
      >
        <Alert status="loading">
          <AlertDescription>
            <Flex width={"fit-content"} alignItems={"center"} gap={"10px"}>
              <Loading h={"2rem"} />
              <Text fontSize={"20px"}> جاري التحميل</Text>
            </Flex>
          </AlertDescription>
        </Alert>
      </Flex>
      <TeacherTableComponent name={""} courses={empty} hours={"0"} />
    </Flex>
  );
  useEffect(() => {
    const getTeachers = async () => {
      try {
        const data = api
          .get("teachers")
          .then((res) => res.data)
          .then((data) => Object.keys(data))
          .then((teachers) => {
            getTeacherTable(teachers[0]);
            updateTeachersList(
              <>
                <Text fontSize={"2xl"}>جدول المعلم:</Text>
                <Select
                  w={"20%"}
                  minW={"15rem"}
                  sx={design.select}
                  onChange={(e) => {
                    getTeacherTable(e.target.value);
                  }}
                  defaultValue={teachers[0]}
                >
                  {teachers.map((teacher) => (
                    <option key={teacher}>{teacher}</option>
                  ))}
                </Select>
              </>
            );
          })
          .catch((e) => {
            updateTeachersList(
              <Flex width={"100%"} flexDir={"column"} alignItems={"center"}>
                <Flex
                  flexDir={"column"}
                  borderRadius={"1rem"}
                  overflow={"hidden"}
                >
                  <Alert status="error">
                    <AlertIcon />
                    <AlertDescription>
                      يبدو اننا لم نستطع الوصول الى المعلمين.
                    </AlertDescription>
                  </Alert>
                </Flex>
                <TeacherTableComponent name={""} courses={empty} hours={"0"} />
              </Flex>
            );
          });
      } catch (e) {
        updateTeachersList(
          <Flex borderRadius={"1rem"} overflow={"hidden"}>
            <Alert status="error">
              <AlertIcon />
              <AlertDescription>
                يبدو اننا لم نستطع الوصول الى جدول المعلم.
              </AlertDescription>
            </Alert>
          </Flex>
        );
      }
    };
    getTeachers();
  }, []);
  return (
    <Flex
      minW={"80rem"}
      w={"100%"}
      alignItems={"center"}
      flexDir={"column"}
      className="teachers-tables"
    >
      <Flex
        alignItems={"center"}
        justifyContent={"center"}
        w={"100%"}
        gap={"10px"}
      >
        {teachersList}
      </Flex>
      {teacherTable}
    </Flex>
  );
}
