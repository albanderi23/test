import { Button, Flex, Select, Text } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import GroupTableComponent from "./GroupTableComponents";
import { design } from "../../style/mainStyle";
import api from "../../api/api";

export default function GroupsTableCountainer() {
  const [group, selectedGroup] = useState("الأمن السيبراني");
  const [level, selectedLevel] = useState(1);
  const [period, selectedPeriod] = useState("صباح");
  const [groupTable, selectedGroupTable] = useState(
    Array.from(Array(5).keys()).map((group) => {
      return (
        <Flex key={group}>
          {GroupTableComponent({
            الاحد: [[], ["الخوارزميات", "معلم 1", "قاعة 3"]],
            الاثنين: [["الخوارزميات", "معلم 1", "قاعة 3"], []],
            الثلاثاء: [[], []],
            الاربعاء: [
              ["الخوارزميات", "معلم 1", "قاعة 3"],
              ["الخوارزميات", "معلم 1", "قاعة 3"],
            ],
            الخميس: [
              ["الخوارزميات", "معلم 1", "قاعة 3"],
              ["الخوارزميات", "معلم 1", "قاعة 3"],
            ],
          })}
        </Flex>
      );
    })
  );
  const examples = ["إدارة الموارد البشرية", 1, "صباح"];
  const [groupTableCount, updateGroupTableCount] = useState(5);
  const [thisData, newData] = useState([]);

  useEffect(() => {
    const updateData = () => {
      selectedGroupTable(
        thisData.map((group, index) => {
          return (
            <Flex key={index}>
              {GroupTableComponent(
                group.courses,
                design.colors.secondary,
                `${group.diploma} شعبة ${group.group} مستوى ${group.level}`,
                group.period
              )}
            </Flex>
          );
        })
      );
    };
    updateData();
  }, [thisData]);

  return (
    <Flex
      gap={"1rem"}
      minW={"80rem"}
      w={"100%"}
      alignItems={"center"}
      flexDir={"column"}
      className="teachers tables"
    >
      <Flex alignItems={"center"} gap={"10px"}>
        <Text fontSize={"2xl"} sx={{ textWrap: "nowrap" }}>
          جدول الشعبة:
        </Text>
        <Select
          w={"20%"}
          minW={"15rem"}
          sx={design.select}
          onChange={(e) => {
            selectedGroup(e.target.value);
          }}
          defaultValue={"الأمن السيبراني"}
        >
          <option value="إدارة الموارد البشرية">إدارة الموارد البشرية</option>
          <option value="إدارة الأعمال">إدارة الأعمال</option>
          <option value="الأمن السيبراني">الأمن السيبراني</option>
          <option value="الصحة والسلامة المهنية">الصحة والسلامة المهنية</option>
          <option value="الذكاء الاصطناعي">الذكاء الاصطناعي</option>
          <option value="التصميم الجرافيكي">التصميم الجرافيكي</option>
          <option value="إدارة الفنادق والمنتجعات السياحية">
            إدارة الفنادق والمنتجعات السياحية
          </option>
          <option value="التأمين وإدارة المخاطر">التأمين وإدارة المخاطر</option>
          <option value="المحاسبة والضرائب">المحاسبة والضرائب</option>
          <option value="التسويق والتجارة الإلكترونية">
            التسويق والتجارة الإلكترونية
          </option>
          <option value="العلاقات العامة والإعلام">
            العلاقات العامة والإعلام
          </option>
          <option value="إدارة سلاسل الإمداد والخدمات اللوجستية">
            إدارة سلاسل الإمداد والخدمات اللوجستية
          </option>
        </Select>
        <Select
          w={"5%"}
          minW={"5rem"}
          sx={design.select}
          onChange={(e) => {
            selectedLevel(e.target.value);
          }}
          defaultValue={1}
        >
          {Array.from(Array(8).keys()).map((num) => (
            <option key={num + 1}>{num + 1}</option>
          ))}
        </Select>
        <Select
          w={"15%"}
          minW={"5rem"}
          sx={design.select}
          onChange={(e) => {
            selectedPeriod(e.target.value);
          }}
          defaultValue={"صباح"}
        >
          {["صباح", "ظهر", "مساء"].map((period) => (
            <option key={period}>{period}</option>
          ))}
        </Select>
        <Button
          sx={design.button.secondary}
          onClick={() => {
            try {
              api
                .get(`diploma`, {
                  params: {
                    diploma: group,
                    level: level,
                    period: period,
                  },
                })
                .then((res) => res.data)
                .then((data) => {
                  newData(data);
                });
            } catch (e) {}
          }}
        >
          بحث
        </Button>
      </Flex>
      <Flex
        className="costumeScrollBar"
        overflow={"auto"}
        w={"85rem"}
        pb={"1rem"}
      >
        <Flex px={"1rem"} gap={"1rem"} minH={"40rem"}>
          {groupTable}
        </Flex>
      </Flex>
    </Flex>
  );
}
