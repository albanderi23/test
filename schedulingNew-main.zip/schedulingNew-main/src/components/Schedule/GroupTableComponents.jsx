import React, { useState } from "react";
import Loading from "../Loading";
import { Container, Flex, Grid, omitThemingProps } from "@chakra-ui/react";
import { design } from "../../style/mainStyle";
import "./TableComponent.css";
import { AutoTextSize } from "auto-text-size";

function GroupTableComponent(
  GroupClasses,
  color = "#ccddff",
  group = "اسم التخصص شعبة # ربع #",
  groupPeriod = "صباح"
) {
  // const [tableDisplay, tableDisplayUpdate] = useState(<></>);

  const time = groupPeriod == "صباح" ? 0 : groupPeriod == "ظهر" ? 1 : 2;
  const tableColor = [
    "الأمن السيبراني",
    "الذكاء الاصطناعي",
    "إدارة الفنادق والمنتجعات السياحية",
    "التسويق والتجارة الإلكترونية",
  ].includes(group.split(" شعبة")[0])
    ? "#DAE9F8"
    : [
        "إدارة الموارد البشرية",
        "إدارة الأعمال",
        "التأمين وإدارة المخاطر",
        "العلاقات العامة والإعلام",
      ].includes(group.split(" شعبة")[0])
    ? "#C1F0C8"
    : [
        "الصحة والسلامة المهنية",
        "التصميم الجرافيكي",
        "المحاسبة والضرائب",
        "إدارة سلاسل الإمداد والخدمات اللوجستية",
      ].includes(group.split(" شعبة")[0])
    ? "#FBE2D5"
    : design.colors.secondary;
  const days = ["الاحد", "الاثنين", "الثلاثاء", "الاربعاء", "الخميس"];
  const period = 0;
  const classesTime = [
    ["8:00-10:00", "10:00-12:00"],
    ["12:00-2:00", "2:00-4:00"],
    ["4:00-6:00", "6:00-8:00"],
  ];

  const studentTable = (
    <Flex
      borderRadius={"1rem"}
      overflow={"hidden"}
      w={"fit-content"}
      border={"1px solid black"}
      bg={"black"}
      boxShadow={"0 3px 5px silver"}
    >
      {/* جدول المحاضرات */}
      <Grid
        color={design.colors.primary}
        gridTemplateColumns={"5rem 10rem 10rem"}
        className="groupTable"
        gap={"1px"}
      >
        <Flex className="headerGroupTable" p={0} bg={tableColor}>
          الشعبة
        </Flex>
        <Flex
          gridColumnStart={"span 2"}
          className="headerGroupTable"
          bg={tableColor}
          textAlign={"center"}
        >
          {group}
        </Flex>
        <Flex className="headerGroupTable" bg={tableColor}></Flex>
        <Flex className="headerGroupTable" bg={tableColor}>
          {classesTime[period + time][0]}
        </Flex>
        <Flex className="headerGroupTable" bg={tableColor}>
          {classesTime[period + time][1]}
        </Flex>
        {Object.values(GroupClasses).map((day, index) => {
          return (
            <React.Fragment key={index}>
              <Flex className="headerGroupTable" bg={tableColor}>
                {days[index]}
              </Flex>
              {day.map((course, index) => {
                return (
                  <Flex
                    key={index}
                    flexDir={"column"}
                    px={"10px"}
                    py={"10px"}
                    minH={"7rem"}
                  >
                    {course.length == 0 ? (
                      <></>
                    ) : (
                      <>
                        <Flex
                          textAlign={"center"}
                          alignItems={"center"}
                          justifyContent={"center"}
                        >
                          {course[0]}
                        </Flex>
                        <Flex alignItems={"center"} justifyContent={"center"}>
                          <AutoTextSize minFontSizePx={14} maxFontSizePx={16}>
                            {course[1]}
                          </AutoTextSize>
                        </Flex>
                        <Flex alignItems={"center"} justifyContent={"center"}>
                          <AutoTextSize minFontSizePx={14} maxFontSizePx={16}>
                            {course[2]}
                          </AutoTextSize>
                        </Flex>
                      </>
                    )}
                  </Flex>
                );
              })}
            </React.Fragment>
          );
        })}
      </Grid>
    </Flex>
  );

  return studentTable;
}

export default GroupTableComponent;
