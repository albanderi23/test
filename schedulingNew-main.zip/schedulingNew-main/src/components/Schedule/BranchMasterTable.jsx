import React, { useEffect, useState } from "react";
import "./scheduleDesign.css";
import { design } from "../../style/mainStyle";
import Edit from "../../icons/Edit";
import { Button, Flex, Text, useToast } from "@chakra-ui/react";
import api from "../../api/api";

export default function BranchMasterTable() {
  const toast = useToast();
  const showToast = () => {
    toast({
      title: "فشل",
      description: "لم نستطع تحديث الجدول.",
      status: "error",
      duration: 5000,
      isClosable: true,
      position: "bottom",
    });
  };
  const [counter, setCounter] = useState(0);
  const [masterData, setMasterData] = useState({});
  useEffect(() => {
    const callApi = async () => {
      try {
        api
          .post("api.php?action=build_branch")
          .then((data) => {
            data.data;
          })
          .then((data) => {
            setMasterData(data);
          })
          .catch((e) => {
            console.log(e);
            showToast();
          });
      } catch (e) {
        showToast();
        console.log(e);
      }
      callApi;
    };
  }, [counter]);
  function exportTablesToExcel() {
    var tables = document.querySelectorAll(".masterTable");
    var html = "";
    tables.forEach(function (table) {
      html += table.outerHTML + "<br/>";
    });
    var url = "data:application/vnd.ms-excel," + encodeURIComponent(html);
    var link = document.createElement("a");
    link.href = url;
    link.download = "branch_schedule.xls";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  const [masterTable, setMasterTable] = useState(<></>);
  useEffect(() => {
    if (masterData.courses) {
      setMasterTable(
        <table
          id="masterTable"
          className="masterTable"
          style={{
            borderRadius: "1rem",
            overflow: "hidden",
            textAlign: "center",
            border: "1px solid black",
            width: "auto",
            boxShadow: "10 10 12px rgba(192, 192, 192, 0.5)",
          }}
        >
          <thead>
            <tr style={{ width: "1%" }}>
              <th
                style={{
                  padding: "10px",
                }}
              >
                اليوم
              </th>
              <th
                style={{
                  padding: "10px",
                }}
              >
                الفترة
              </th>
              {masterData.rooms.map((room) => (
                <th
                  style={{
                    padding: "10px",
                  }}
                  key={room}
                >
                  {room}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Object.keys(masterData ? masterData.courses : {}).map((day) => {
              return Object.keys(masterData.courses[day]).map((time, index) => {
                return (
                  <tr style={{ width: "1%" }} key={index}>
                    {index == 0 ? (
                      <th
                        style={{
                          padding: "10px",
                        }}
                        rowSpan={6}
                      >
                        {day}
                      </th>
                    ) : undefined}
                    <td
                      style={{
                        border: "1px solid black",
                        padding: "10px",
                      }}
                      key={time + day}
                    >
                      {time}
                    </td>
                    {Object.values(masterData.courses[day][time]).map(
                      (room) => {
                        if (room && room.course) {
                          return (
                            <td
                              style={{
                                whiteSpace: "pre-wrap",
                                border: "1px solid black",
                                padding: "10px",
                              }}
                            >
                              {room.course.groupName}
                              <br />
                              {room.course.course}
                              <br />
                              {room.course.trainerName}
                              <br />
                              {room.type}
                            </td>
                          );
                        }
                        return (
                          <td
                            style={{
                              border: "1px solid black",
                              padding: "10px",
                            }}
                          ></td>
                        );
                      }
                    )}
                  </tr>
                );
              });
            })}
          </tbody>
        </table>
      );
    }
  }, [masterData]);
  return (
    <Flex
      alignContent={"center"}
      minH={"80dvh"}
      gap={"3rem"}
      flexDir={"column"}
      minW={"80dvw"}
    >
      <Flex justifyContent={"center"} gap={"1rem"} w={"100%"}>
        <Button
          sx={design.button.primary}
          onClick={() => {
            setCounter(counter + 1);
          }}
        >
          انشاء جدول جديد
        </Button>
        <Button
          sx={design.button.secondary}
          onClick={() => {
            exportTablesToExcel();
          }}
        >
          تنزيل الجدول في ملف Excel
        </Button>
      </Flex>
      {masterTable}
    </Flex>
  );
}
