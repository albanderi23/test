import { createSlice, current } from "@reduxjs/toolkit";

const initialState = {
  value: {},
  state: false,
  courses: {},
};

const teachersSlice = createSlice({
  name: "teachers",
  initialState,
  reducers: {
    changeState: (state) => {
      if (!state.state) {
        state.state = true;
      }
    },
    addCourses: (state, action) => {
      state.courses = action.payload.courses.reduce(
        (courses, currentCourse) => {
          return { ...courses, [currentCourse.id]: currentCourse.name };
        },
        {}
      );
    },
    addTeacher: (state, action) => {
      state.value = {
        ...state.value,
        [action.payload.id
          ? action.payload.id
          : "new" +
            Date.now().toString(36) +
            Math.random().toString(36).slice(2)]: {
          courses: action.payload.courses ? action.payload.courses : [],
          shifts: action.payload.periods
            ? action.payload.periods
            : [false, false, false],
          isNew: action.payload.isNew == null ? true : action.payload.isNew,
          name: action.payload.name,
          isDeleted: false,
          deletedCourses: [],
          addedCourses: [],
          swappedShifts: action.payload.periods
            ? action.payload.periods
            : [false, false, false],
        },
      };
    },
    deleteTeacher: (state, action) => {
      if (state.value[action.payload.id].isNew) {
        const filtered = Object.keys(state.value)
          .filter((id) => id !== action.payload.id)
          .reduce((acc, id) => {
            acc[id] = state.value[id];
            return acc;
          }, {});

        state.value = filtered;
      } else {
        state.value[action.payload.id] = {
          ...state.value[action.payload.id],
          isDeleted: !state.value[action.payload.id].isDeleted,
        };
      }
    },
    addCourse: (state, action) => {
      state.value[action.payload.id] = {
        ...state.value[action.payload.id],
        addedCourses: [
          ...state.value[action.payload.id].addedCourses,
          action.payload.course,
        ],
      };
    },
    deleteCourse: (state, action) => {
      if (
        state.value[action.payload.id].deletedCourses.includes(
          action.payload.course
        )
      ) {
        state.value[action.payload.id].deletedCourses = state.value[
          action.payload.id
        ].deletedCourses.filter((course) => course != action.payload.course);
      } else if (
        state.value[action.payload.id].addedCourses.includes(
          action.payload.course
        )
      ) {
        state.value[action.payload.id].addedCourses = state.value[
          action.payload.id
        ].addedCourses.filter((course) => course != action.payload.course);
      } else {
        state.value[action.payload.id].deletedCourses = [
          ...state.value[action.payload.id].deletedCourses,
          action.payload.course,
        ];
      }
    },
    swapShifts: (state, action) => {
      state.value[action.payload.id].swappedShifts = [
        action.payload.morning,
        action.payload.afternoon,
        action.payload.evening,
      ];
    },
    normalizeTeachers: (state) => {
      const updatedList = Object.keys(state.value)
        .filter((id) => !state.value[id].isDeleted)
        .reduce((teachers, currentTeacher) => {
          return {
            ...teachers,
            [currentTeacher]: {
              ...state.value[currentTeacher],
              courses: [
                ...state.value[currentTeacher].courses.filter(
                  (course) =>
                    !state.value[currentTeacher].deletedCourses.includes(course)
                ),
                ...state.value[currentTeacher].addedCourses,
              ],
              shifts: state.value[currentTeacher].swappedShifts,
              deletedCourses: [],
              addedCourses: [],
              isNew: false,
            },
          };
        }, {});
      state.value = updatedList;
    },
  },
});

export const {
  swapShifts,
  deleteCourse,
  addCourse,
  deleteTeacher,
  addTeacher,
  normalizeTeachers,
  changeState,
  addCourses,
} = teachersSlice.actions;
export default teachersSlice.reducer;
