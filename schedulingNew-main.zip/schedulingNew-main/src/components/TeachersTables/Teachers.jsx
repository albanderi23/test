import { Button, Flex, Input, Text } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import "./Teachers.css";
import { design } from "../../style/mainStyle";
import TeacherDisplay from "./TeacherDisplay";
import AlertingMessage from "../../assets/AlertingMessage";
import api from "../../api/api";
import { useDispatch, useSelector } from "react-redux";
import { addCourses, addTeacher, normalizeTeachers } from "./TeachersSlice";

export default function Teachers() {
  const controlTeachers = useDispatch();

  const loginData = useSelector((state) => state.login);
  const [newTeacher, updateNewTeacher] = useState("");
  const [deletedTeachersList, updateDeletedTeachersList] = useState([]);
  const subjects = useSelector((state) => state.teachers.courses);
  useEffect(() => {
    if (Object.keys(subjects).length == 0) {
      try {
        api
          .get("api.php?action=subjects", {
            params: {
              branch: loginData.branch_id,
            },
          })
          .then((data) => {
            return data.data;
          })
          .then((data) => {
            controlTeachers(addCourses({ courses: data }));
          });
      } catch (e) {
        console.log(e);
      }
    }
  }, []);
  const teachersList = useSelector((state) => state.teachers.value);

  const [changesToTeachers, updateChangesToTeachers] = useState({});
  const [changesToTeachersMain, updateChangesToTeachersMain] = useState({});
  const [message, setMessage] = useState("");

  useEffect(() => {
    updateChangesToTeachersMain({
      ...changesToTeachersMain,
      ...changesToTeachers,
    });
  }, [changesToTeachers]);

  const [displayCurrentTeachers, updatedisplayCurrentTeachers] = useState(
    <AlertingMessage type={"loading"} message={"جاري تحميل المعلمين"} />
  );
  useEffect(() => {
    console.log(teachersList);
    updatedisplayCurrentTeachers(
      Object.keys(teachersList)
        .filter((id) => !(teachersList[id].isNew && teachersList[id].isDeleted))
        .map((teacher) => buildTeacher(teacher, false))
    );
  }, [teachersList]);

  const buildTeacher = (teacher, mode) => {
    return (
      <React.Fragment key={teacher}>
        <TeacherDisplay
          key={teacher + "t"}
          id={teacher}
          name={teachersList[teacher].name}
          periods={teachersList[teacher].periods}
          courses={teachersList[teacher]["courses"]}
          updateChangesToTeachers={updateChangesToTeachers}
          isNew={mode}
          deletedTeachersList={deletedTeachersList}
        />
      </React.Fragment>
    );
  };

  useEffect(() => {
    const receiveTeachers = async () => {
      api
        .get("api.php?action=trainers", {
          params: {
            branch: loginData.value.branch_id,
          },
        })
        .then((res) => res.data)
        .then((data) => {
          console.log(data);
          data.map((teacher) => {
            controlTeachers(
              addTeacher({
                name: teacher.name,
                id: teacher.trainer_id,
                periods: teacher.periods,
                isNew: false,
                courses: teacher.subjects.filter((course) => course != 0),
              })
            );
          });
        });
    };
    if (Object.keys(teachersList).length < 1) {
      receiveTeachers();
    }
  }, []);

  const examples = {
    active: {
      bg: design.colors.primary,
      color: design.colors.secondary,
      borderRadius: "1rem",
      border: `2px solid ${design.colors.secondary}`,
      fontSize: "md",
      w: "5rem",
      padding: ".5rem",
      textAlign: "center",
    },
    inactive: {
      bg: design.colors.secondary,
      color: design.colors.primary,
      borderRadius: "1rem",
      border: "2px solid black",
      fontSize: "md",
      padding: ".5rem",
      textAlign: "center",
      w: "5rem",
    },
    activate: {
      bg: "#c1f0c8",
      color: design.colors.primary,
      borderRadius: "1rem",
      border: "2px solid black",
      fontSize: "md",
      w: "5rem",
      textAlign: "center",
      padding: ".5rem",
    },
    deactivate: {
      bg: "#ffa9a9",
      color: design.colors.primary,
      borderRadius: "1rem",
      border: "2px solid black",
      fontSize: "md",
      w: "5rem",
      textAlign: "center",
      padding: ".5rem",
    },
  };

  return (
    <>
      <Flex className="currentTeachers">
        <Flex
          alignItems={"center"}
          fontSize={"3xl"}
          color={design.colors.secondary}
          gap={"10px"}
        >
          <Text>الوان الخلفية:</Text>
          <Text sx={examples.active}>فعال</Text>
          <Text sx={examples.inactive}>غير فعال</Text>
          <Text sx={examples.activate}>مضاف</Text>
          <Text sx={examples.deactivate}>ملغي</Text>
        </Flex>
        {displayCurrentTeachers}
        <Flex className="displayTeacher" bg={design.colors.secondary}>
          <Flex gap={"10px"}>
            <Input
              value={newTeacher}
              bg={"white"}
              boxShadow={"inner"}
              border={"1px #d0d0d0 solid"}
              width={"20%"}
              onChange={(e) => {
                updateNewTeacher(e.target.value);
              }}
            />
            <Button
              borderRadius={"1rem"}
              w={"fit-content"}
              sx={design.button.primary}
              onClick={() => {
                controlTeachers(addTeacher({ name: newTeacher }));
                updateNewTeacher("");
              }}
            >
              اضافة مدرب
            </Button>
          </Flex>
          <Flex flexWrap={"wrap"} flexDir={"row"} gap={"10px"}>
            <Button visibility={"hidden"}></Button>
          </Flex>
        </Flex>
        {message}
        <Button
          w={"fit-content"}
          sx={design.button.secondary}
          mb={"1rem"}
          onClick={async () => {
            console.log(loginData.value.branch_id);
            const apiData = {
              branch: loginData.value.branch_id,
              trainerUpdates: {
                ...teachersList,
              },
            };
            console.log(apiData);
            const result = await api
              .post("api.php?action=trainers", {
                ...apiData,
              })
              .then(controlTeachers(normalizeTeachers()))
              .catch((e) => console.log(e));
            console.log(result);
          }}
        >
          حفظ التغييرات
        </Button>
      </Flex>
    </>
  );
}
