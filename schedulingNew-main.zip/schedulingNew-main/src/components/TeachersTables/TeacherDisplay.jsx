import { Button, Flex, Text } from "@chakra-ui/react";
import { design } from "../../style/mainStyle";
import "./Teachers.css";
import Select from "react-select";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  addCourse,
  deleteCourse,
  deleteTeacher,
  swapShifts,
} from "./TeachersSlice";

export default function TeacherDisplay(params) {
  const teacher = useSelector((state) => state.teachers.value[params.id]);

  const optionsBuild = () => {
    if (!teacher) return;
    return Object.keys(allCourses)
      .filter(
        (course) =>
          ![
            ...teacher.addedCourses.map((course) => course + ""),
            ...teacher.courses.map((course) => course + ""),
          ].includes(course)
      )
      .map((course) => {
        return { value: parseInt(course), label: allCourses[course] };
      });
  };

  const allCourses = useSelector((state) => state.teachers.courses);

  const [options, updateOptions] = useState(optionsBuild());
  useEffect(() => {
    if (!teacher) return;
    updateOptions(optionsBuild());
  }, [teacher]);

  const editTeacher = useDispatch();

  const [changesToMake, updateChangesToMake] = useState({
    courses: [],
    Periods: [],
    isNew: params.isNew,
    name: params.name,
    id: params.id,
  });

  useEffect(() => {
    params.updateChangesToTeachers({
      [params.id]: changesToMake,
    });
  }, [changesToMake]);
  const getShiftStyle = (shift) => {
    return teacher.shifts[shift] == teacher.swappedShifts[shift]
      ? teacher.shifts[shift]
        ? design.button.primary
        : design.button.secondary
      : teacher.shifts[shift]
      ? design.button.deleted
      : design.button.added;
  };

  const deleteCourseStyle = (courseName) => {
    if (teacher.courses.includes(courseName)) {
      return !teacher.deletedCourses.includes(courseName)
        ? design.button.primary
        : design.button.deleted;
    } else {
      return design.button.added;
    }
  };

  const [shiftsDisplay, updateShiftsDisplay] = useState([]);
  const [coursesDisplay, updateCoursesDisplay] = useState(<></>);

  useEffect(() => {
    if (!teacher) return;
    updateCoursesDisplay(
      [...teacher.courses, ...teacher.addedCourses].map((course) => {
        return (
          <Button
            key={course}
            sx={deleteCourseStyle(course)}
            onClick={() => {
              editTeacher(
                deleteCourse({
                  id: params.id,
                  course: course,
                  deletedCourses: teacher.deletedCourses,
                  addedCourses: teacher.addedCourses,
                })
              );
            }}
          >
            <Text ml={"5px"}>{allCourses[course]}</Text>
          </Button>
        );
      })
    );
  }, [teacher]);

  useEffect(() => {
    if (!teacher) return;
    updateShiftsDisplay(
      <Flex gap={"5px"} alignItems={"center"}>
        <Text fontSize={"x-large"}>الفترات:</Text>
        <Button
          sx={getShiftStyle(0)}
          onClick={() => {
            editTeacher(
              swapShifts({
                id: params.id,
                morning: !teacher.swappedShifts[0],
                afternoon: teacher.swappedShifts[1],
                evening: teacher.swappedShifts[2],
              })
            );
          }}
        >
          <Text ml={"5px"}>صباح</Text>
        </Button>
        <Button
          sx={getShiftStyle(1)}
          onClick={() => {
            editTeacher(
              swapShifts({
                id: params.id,
                morning: teacher.swappedShifts[0],
                afternoon: !teacher.swappedShifts[1],
                evening: teacher.swappedShifts[2],
              })
            );
          }}
        >
          <Text ml={"5px"}>ظهر</Text>
        </Button>
        <Button
          sx={getShiftStyle(2)}
          onClick={() => {
            editTeacher(
              swapShifts({
                id: params.id,
                morning: teacher.swappedShifts[0],
                afternoon: teacher.swappedShifts[1],
                evening: !teacher.swappedShifts[2],
              })
            );
          }}
        >
          <Text ml={"5px"}>مساء</Text>
        </Button>
      </Flex>
    );
  }, [teacher]);

  const [cardBG, updateCardBG] = useState(
    teacher && teacher.isNew ? design.colors.added : design.colors.secondary
  );

  useEffect(() => {
    if (!teacher) return;
    if (teacher.isDeleted) {
      updateCardBG(design.colors.deleted);
    } else {
      updateCardBG(
        teacher.isNew ? design.colors.added : design.colors.secondary
      );
    }
  }, [teacher]);

  return (
    <Flex transition={".3s"} className="displayTeacher" bg={cardBG}>
      <Flex justifyContent={"space-between"}>
        <Text fontSize={"2xl"} fontWeight={"bold"}>
          {teacher ? teacher.name : ""}
          <Button
            mr={"10px"}
            sx={design.button.deleted}
            onClick={() => {
              editTeacher(deleteTeacher({ id: params.id }));
            }}
          >
            حذف المدرب
          </Button>
        </Text>
        {shiftsDisplay}
      </Flex>
      <Flex flexWrap={"wrap"} flexDir={"row"} gap={"10px"}>
        {coursesDisplay}

        <Flex gap={"10px"} alignItems={"center"}>
          <Select
            onChange={(e) => {
              if (e != undefined) {
                editTeacher(addCourse({ id: params.id, course: e.value }));
                updateOptions(optionsBuild());
              }
            }}
            styles={{ w: "10rem" }}
            className="basic-single"
            classNamePrefix="select"
            isDisabled={false}
            isLoading={false}
            isClearable={true}
            isRtl={true}
            isSearchable={true}
            name="color"
            options={options}
            placeholder={"اضافة مواد"}
          />
        </Flex>
      </Flex>
    </Flex>
  );
}
