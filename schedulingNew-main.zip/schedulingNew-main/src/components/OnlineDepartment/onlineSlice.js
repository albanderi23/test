import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: {
    diplomas: {},
    diplomasNames: {},
    periods: {},
    coursesList: {},
    courses: {},
    trainers: {},
    branches: {},
  },
};

const defaultPeriod = {
  branches: [],
  isNew: true,
  isDeleted: false,
  trainer: "",
  subject: 0,
  period: "",
  days: {
    الأحد: [false, false],
    الاثنين: [false, false],
    الثلاثاء: [false, false],
    الأربعاء: [false, false],
    الخميس: [false, false],
  },
};

const defaultCourse = {
  name: "",
  periods: [],
};

const onlineSlice = createSlice({
  name: "online",
  initialState,
  reducers: {
    addDiplomaName: (state, action) => {
      state.value.diplomasNames = {
        ...state.value.diplomasNames,
        ...action.payload,
      };
    },
    addMeta: (state, action) => {
      state.value.branches = action.payload.branches;
      state.value.trainers = action.payload.trainers;
    },
    addOnlineDiploma: (state, action) => {
      if (state.value.diplomas[action.payload.diploma.id]) {
        return;
      }
      state.value.diplomas = {
        ...state.value.diplomas,
        [action.payload.diploma.id]: {
          name: action.payload.diploma.name,
          periods: [],
        },
      };
    },
    addOnlinePeriod: (state, action) => {
      state.value.periods = {
        ...state.value.periods,
        [action.payload.id]: {
          ...defaultPeriod,
          ...action.payload,
        },
      };
      state.value.diplomas[action.payload.diploma].periods = [
        ...state.value.diplomas[action.payload.diploma].periods,
        action.payload.id,
      ];
    },
    addCoursesList: (state, action) => {
      state.value.coursesList = action.payload.coursesList;
    },
    deletePeriod: (state, action) => {
      const filteredList = state.value.diplomas[
        action.payload.diploma
      ].periods.filter((periodID) => periodID != action.payload.id);
      state.value.diplomas[action.payload.diploma].periods = [...filteredList];
      state.value.periods = Object.keys(state.value.periods).reduce(
        (periods, currentPeriod) => {
          return currentPeriod == action.payload.id
            ? periods
            : {
                ...periods,
                [currentPeriod]: { ...state.value.periods[currentPeriod] },
              };
        },
        {}
      );
    },
    addOnlineCourse: function (state, action) {
      state.value.courses = {
        [action.payload.id]: {
          ...defaultCourse,
          name: action.payload.name,
        },
        ...state.value.courses,
      };
    },
    updateOnlineCoursePeriod: function (state, action) {
      state.value.periods[action.payload.period] = {
        ...action.payload.updates,
      };
    },
  },
});

export const {
  addOnlineCourse,
  addOnlinePeriod,
  updateOnlineCoursePeriod,
  deletePeriod,
  addOnlineDiploma,
  addCoursesList,
  addMeta,
  addDiplomaName,
} = onlineSlice.actions;
export default onlineSlice.reducer;
