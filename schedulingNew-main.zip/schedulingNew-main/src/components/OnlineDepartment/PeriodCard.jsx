import {
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Grid,
  Heading,
  Input,
  Select,
  Text,
  useToast,
} from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import "./scheduleDesign.css";
import { design } from "../../style/mainStyle";
import Edit from "../../icons/Edit";
import { useDispatch, useSelector } from "react-redux";
import { deletePeriod, updateOnlineCoursePeriod } from "./onlineSlice";
import Trash from "../../icons/Trash";
import api from "../../api/api";

export default function PeriodCard(props) {
  const dispatch = useDispatch();
  const data = useSelector((state) => state.online.value.periods[props.id]);
  const title = useSelector((state) => state.online.value.coursesList);
  console.log(title);
  const branchesList = useSelector((state) => state.online.value.branches);
  const toast = useToast();
  const showToast = () => {
    toast({
      title: "خطا",
      description: "بعض المعلومات مفقودة او ان المادة لا تتواجد في الدبلوم",
      status: "error",
      position: "bottom",
      duration: 5000,
      isClosable: true,
    });
  };
  useEffect(() => {
    console.log(data);
  }, []);
  const initeacher = useSelector(
    (state) => state.online.value.periods[props.id].trainer
  );

  const iniPeriod = useSelector(
    (state) => state.online.value.periods[props.id].period
  );
  const inidays = useSelector(
    (state) => state.online.value.periods[props.id].days
  );
  const inibranches = useSelector(
    (state) => state.online.value.periods[props.id].branches
  );
  const courseName = useSelector(
    (state) => state.online.value.periods[props.id].subject_id
  );

  const [teacher, setTeacher] = useState(initeacher);
  const [period, setPeriod] = useState(iniPeriod);
  const [days, setDays] = useState(inidays);
  const [branches, setBranches] = useState(inibranches);

  const [isDeleted, setDeleted] = useState(false);
  const [updating, setUpdate] = useState(
    (data.id + "").includes("new") ? true : false
  );

  const [theme, setTheme] = useState(design.periods.default);

  useEffect(() => {
    console.log([1, 2, 3].includes(period));
    if ([1, 2, 3].includes(period)) {
      setTheme(
        design.periods[{ 1: "morning", 2: "afternoon", 3: "evening" }[period]]
      );
    } else {
      setTheme(design.periods.default);
    }
  }, [period]);

  const buttonStyle = {
    bg: "rgb(240,240,240)",
    cursor: "pointer",
    borderRadius: "0",
  };
  const [extended, setExtended] = useState(true);
  return (
    <Card
      alignSelf={"flex-start"}
      border={"1px solid silver"}
      alignItems={"center"}
      overflow={"hidden"}
      borderRadius={"1rem"}
      bg={isDeleted ? design.colors.deleted : "white"}
      w={"fit-content"}
      transition={".5s"}
    >
      <CardHeader
        transition={".2s"}
        p={".5rem"}
        color={updating ? design.colors.primary : theme.fontColor}
        w={"100%"}
        background={updating ? design.colors.added : theme.color}
        cursor={"pointer"}
        onClick={(event) => {}}
      >
        <Flex alignItems={"center"} justifyContent={"space-between"}>
          {updating ? (
            <Flex w={"2.2rem"}></Flex>
          ) : (
            <Flex
              id={"editContainer"}
              display={extended ? "flex" : "none"}
              alignItems={"center"}
              justifyContent={"center"}
              w={"2.2rem"}
              height={"2.2rem"}
              transition={".3s"}
              borderRadius={"3rem"}
              _hover={{ bg: design.colors.deleted }}
              onClick={(e) => {
                if (iniPeriod === "") {
                  dispatch(
                    deletePeriod({ id: props.id, course: props.courseID })
                  );
                  setUpdate(true);
                } else {
                  setDeleted(true);
                  setUpdate(true);
                }

                e.stopPropagation();
              }}
            >
              <Trash />
            </Flex>
          )}
          <Heading
            userSelect={"none"}
            mx={"auto"}
            textAlign={"center"}
            size={"lg"}
            maxW={"15rem"}
            overflow={"hidden"}
          >
            {title[data.subject_id || data.subject]}
          </Heading>
          <Flex w={"2.2rem"}></Flex>
        </Flex>
      </CardHeader>
      <CardBody
        alignItems={"center"}
        display={"flex"}
        flexDir={"column"}
        gap={".5rem"}
        p={"20px"}
      >
        <Flex gap={"10px"} justifyContent={"space-between"} width={"20rem"}>
          <Input
            flex={"3 0 auto"}
            w={"11rem"}
            sx={{
              ...design.input,
              bg:
                teacher == initeacher && !updating
                  ? "white"
                  : design.colors.added,
            }}
            disabled={!updating}
            value={teacher}
            onChange={(event) => {
              setTeacher(event.target.value);
            }}
            placeholder="المدرب"
          />
          <Select
            w={"6rem"}
            sx={{
              ...design.input,
              bg:
                period == iniPeriod && !updating
                  ? "white"
                  : design.colors.added,
            }}
            disabled={!updating}
            value={period}
            onChange={(event) => {
              setPeriod(
                event.target.value
                  ? parseInt(event.target.value)
                  : event.target.value
              );
            }}
            placeholder="الفترة"
          >
            <option value={1}>الصباح</option>
            <option value={2}>الظهر</option>
            <option value={3}>المساء</option>
          </Select>
        </Flex>
        <Flex gap={"1rem"} justifyContent={"space-between"}>
          <Flex flexDir="column" alignItems={"center"}>
            <Text fontSize={"1.2rem"}>الاوقات</Text>
            <Grid
              borderRadius={"1rem"}
              overflow={"hidden"}
              border={"1px silver solid"}
              gap={"1px"}
              bg={"silver"}
              gridTemplateColumns={"auto auto auto"}
            >
              <Text p={"5px"} textAlign={"center"} bg={theme.color}></Text>
              <Text
                p={"5px"}
                color={theme.fontColor}
                textAlign={"center"}
                bg={theme.color}
                fontWeight={"bold"}
              >
                الاولى
              </Text>
              <Text
                p={"5px"}
                color={theme.fontColor}
                fontWeight={"bold"}
                textAlign={"center"}
                bg={theme.color}
              >
                الثانية
              </Text>
              {Object.keys(days).map((day) => {
                return (
                  <React.Fragment key={day}>
                    <Text
                      p={"5px"}
                      textAlign={"center"}
                      color={theme.fontColor}
                      fontWeight={"bold"}
                      bg={theme.color}
                    >
                      {day}
                    </Text>
                    <Button
                      key={day + 1}
                      onClick={() => {
                        if (updating) {
                          setDays({
                            ...days,
                            [day]: [!days[day][0], days[day][1]],
                          });
                        }
                      }}
                      sx={{
                        ...buttonStyle,
                        bg: updating
                          ? days[day][0] == inidays[day][0]
                            ? "linear-gradient(180deg,rgba(255, 255, 255, 1) 0%, rgba(222, 222, 222, 1) 100%)"
                            : days[day][0]
                            ? design.colors.added
                            : design.colors.deleted
                          : "rgba(240, 240, 240, 1)",
                      }}
                    >
                      {days[day][0]
                        ? "✓"
                        : days[day][0] != inidays[day][0]
                        ? "✗"
                        : ""}
                    </Button>
                    <Button
                      key={day + 2}
                      onClick={() => {
                        if (updating) {
                          setDays({
                            ...days,
                            [day]: [days[day][0], !days[day][1]],
                          });
                        }
                      }}
                      sx={{
                        ...buttonStyle,
                        bg: updating
                          ? days[day][1] == inidays[day][1]
                            ? "linear-gradient(180deg,rgba(255, 255, 255, 1) 0%, rgba(222, 222, 222, 1) 100%)"
                            : days[day][1]
                            ? design.colors.added
                            : design.colors.deleted
                          : "rgba(240, 240, 240, 1)",
                      }}
                    >
                      {days[day][1] ? "✓" : ""}
                    </Button>
                  </React.Fragment>
                );
              })}
            </Grid>
          </Flex>
          <Flex flexDir="column" alignItems={"center"}>
            <Text fontSize={"1.2rem"}>الفروع</Text>
            <Flex
              className="costumeScrollBarY"
              gap={"1px"}
              bg={"silver"}
              border={"1px solid silver"}
              borderRadius={"0 1rem 1rem 0"}
              height={"15rem"}
              width={"10rem"}
              overflow={"auto"}
              flexDir={"column"}
            >
              {Object.keys(branchesList || {}).map((branch) => (
                <Button
                  key={branch}
                  style={buttonStyle}
                  minH={"2rem"}
                  fontWeight={"normal"}
                  color={branches.includes(branch) ? "white" : undefined}
                  bg={
                    branches.includes(branch) && updating
                      ? inibranches.includes(branch)
                        ? theme.color
                        : design.colors.added
                      : updating
                      ? !inibranches.includes(branch)
                        ? "linear-gradient(180deg,rgba(255, 255, 255, 1) 0%, rgba(222, 222, 222, 1) 100%)"
                        : design.colors.deleted
                      : "rgba(240, 240, 240, 1)"
                  }
                  onClick={() => {
                    if (updating) {
                      setBranches(
                        branches.includes(branch)
                          ? branches.filter((branchID) => branch != branchID)
                          : [...branches, branch]
                      );
                    }
                  }}
                  border={"1px balck solid"}
                >
                  {branchesList[branch]}
                </Button>
              ))}
            </Flex>
          </Flex>
        </Flex>
        <Flex
          w={"100%"}
          justifyContent={"space-evenly"}
          display={updating ? "flex" : "none"}
        >
          <Text
            fontWeight={"bold"}
            bg={theme.color}
            onClick={async () => {
              const update = {
                trainer: teacher,
                period: period,
                days: days,
                branches: branches,
                id: data.id,
                subject_id: data.subject,
                subject: data.subject,
                diploma_id: parseInt(data.diploma),
                diploma: data.diploma,
              };
              console.log({
                time: update.days,
                trainer: update.trainer,
                branches: update.branches.map((branch) => parseInt(branch)),
                diploma_id: update.diploma_id,
                subject_id: parseInt(update.subject),
                period: update.period,
              });
              api
                .post("api.php?action=online&oAction=bulk_add", {
                  time: update.days,
                  trainer: update.trainer,
                  branches: update.branches.map((branch) => parseInt(branch)),
                  diploma_id: update.diploma_id,
                  subject_id: parseInt(update.subject),
                  period: update.period,
                })
                .then((data) => {
                  console.log(data);
                  dispatch(
                    updateOnlineCoursePeriod({
                      period: data.id,
                      updates: { ...update },
                    })
                  );
                  setUpdate(false);
                })
                .catch((e) => {
                  showToast();
                  console.log(e);
                });
            }}
            borderRadius={"1rem"}
            color={"white"}
            px={".8rem"}
            cursor={"pointer"}
            transition={".2s"}
            userSelect={"none"}
            _hover={{ bg: design.colors.added }}
          >
            حفظ
          </Text>{" "}
          <Text
            userSelect={"none"}
            color={"silver"}
            cursor={"pointer"}
            _hover={{ textDecoration: "underline" }}
            onClick={() => {
              dispatch(deletePeriod({ id: data.id, diploma: data.diploma }));
            }}
          >
            الغاء
          </Text>
        </Flex>
      </CardBody>
    </Card>
  );
}
