import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Button,
  Flex,
  Heading,
} from "@chakra-ui/react";
import "./scheduleDesign.css";
import { design } from "../../style/mainStyle";
import PeriodCard from "./PeriodCard";
import { useSelector, useDispatch } from "react-redux";
import { addOnlinePeriod } from "./onlineSlice";
import { useEffect, useState } from "react";
import Select from "react-select";
import { current } from "@reduxjs/toolkit";

export default function OnlineDiplomas(params) {
  const diplomasSelector = useSelector((state) => state.online.value.diplomas);
  console.log(diplomasSelector);
  const diplomasNames = useSelector(
    (state) => state.online.value.diplomasNames
  );
  const [currentCourse, setCurrentCourse] = useState(undefined);
  const data = useSelector((state) => state.online);

  const coursesList = useSelector((state) => state.online.value.coursesList);

  const diplomas = Object.keys(diplomasSelector || []);
  useEffect(() => {}, [diplomas]);
  const dispatch = useDispatch();
  return (
    <Accordion
      gap={"1rem"}
      p={"2px"}
      display={"flex"}
      flexDir={"column"}
      minWidth={"85rem"}
      allowToggle
    >
      {diplomas.map(
        (
          diploma //create courses list
        ) => (
          <AccordionItem key={diploma}>
            {({ isExpanded }) => (
              <Flex
                border={"1px silver solid"}
                borderRadius={"1rem"}
                gap={"1rem"}
                w={"100%"}
                flexDir={"column"}
                overflow={"hidden"}
              >
                <AccordionButton
                  bg={
                    isExpanded
                      ? "silver"
                      : "linear-gradient(180deg,rgba(240, 240, 240, 1) 0%, rgba(210, 210, 210, 1) 100%)"
                  }
                  color={isExpanded ? design.colors.primary : ""}
                  shadow={"md"}
                >
                  <Heading mx={"auto"} size={"lg"} textAlign={"center"}>
                    {diplomasNames[diploma]}
                  </Heading>
                  <AccordionIcon />
                </AccordionButton>
                <AccordionPanel>
                  <Flex
                    mb={"2rem"}
                    gap={"20px"}
                    justifyContent={"center"}
                    w={"100%"}
                  >
                    <Select
                      onChange={(e) => {
                        setCurrentCourse(e.value);
                      }}
                      className="selectDisplay"
                      classNamePrefix="select"
                      isDisabled={false}
                      isLoading={false}
                      menuPortalTarget={document.body}
                      styles={{
                        singleValuecontrol: (base) => ({
                          ...base,
                          color: "black", // Text color in the input
                        }),
                        singleValue: (base) => ({
                          ...base,
                          color: "black", // Selected value text
                        }),
                        option: (base, state) => ({
                          ...base,
                          color: "black", // Text color
                          backgroundColor: state.isSelected
                            ? "#007bff" // Selected option background
                            : state.isFocused
                            ? base.backgroundColor // Use default hover color
                            : "white",
                        }),
                      }}
                      isRtl={true}
                      isSearchable={true}
                      options={Object.keys(coursesList || {}).map((course) => {
                        return { value: course, label: coursesList[course] };
                      })}
                      placeholder={"اضافة مادة"}
                    />
                    <Button
                      onClick={() => {
                        if (currentCourse) {
                          const id = //randomize ID
                            "new" +
                            Date.now().toString(36) +
                            Math.random().toString(36).slice(2);
                          dispatch(
                            addOnlinePeriod({
                              id: id,
                              diploma: diploma,
                              subject: currentCourse,
                            })
                          );
                        }
                      }}
                      sx={design.button.primary}
                    >
                      اضافة جلسة جديدة
                    </Button>
                  </Flex>
                  <Flex gap={"1rem"} alignItems={"center"} flexDir={"column"}>
                    <Flex
                      w={"100%"}
                      gap={"10px"}
                      flexWrap={"wrap"}
                      maxW={"100%"}
                      justifyContent={"space-around"}
                    >
                      {diplomasSelector[diploma].periods
                        .map(
                          (
                            periodCard //create card for each period inside course
                          ) => (
                            <PeriodCard
                              key={periodCard}
                              id={periodCard}
                              diploma={diploma}
                            />
                          )
                        )
                        .reverse()}
                    </Flex>
                    <Button
                      w={"fit-content"}
                      display={"none"}
                      sx={design.button.added}
                    >
                      حفظ
                    </Button>
                  </Flex>
                </AccordionPanel>
              </Flex>
            )}
          </AccordionItem>
        )
      )}
    </Accordion>
  );
}
