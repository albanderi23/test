import React, { useEffect, useState } from "react";
import OnlineDiplomas from "./OnlineDiploma";
import { Button, Flex } from "@chakra-ui/react";
import { design } from "../../style/mainStyle";
import { useDispatch, useSelector } from "react-redux";
import {
  addCoursesList,
  addDiplomaName,
  addMeta,
  addOnlineCourse,
  addOnlineDiploma,
  addOnlinePeriod,
} from "./onlineSlice";
import Select from "react-select";
import api from "../../api/api";
import "./scheduleDesign.css";

export default function OnlineContainer() {
  const loginData = useSelector((state) => state.login.value);
  const data = useSelector((state) => state.online.value);
  const diplomasList = useSelector((state) => state.online.value.diplomasNames);
  const [currentDiploma, setCurrentDiploma] = useState();
  useEffect(() => {
    console.log(data);
  }, [data]);
  const dispatch = useDispatch();
  useEffect(() => {
    const apiCall = async () => {
      try {
        await api
          .get("api.php?action=diplomas", {
            params: { branch: loginData.branch_id },
          })
          .then((data) => data.data)
          .then((data) => {
            dispatch(
              addDiplomaName(
                data.reduce((diplomasList, diploma) => {
                  return {
                    ...diplomasList,
                    [diploma.id]: diploma.name,
                  };
                }, {})
              )
            );
          })
          .then(() => {
            try {
              api
                .get("api.php?action=online", {
                  params: { oAction: "meta", branch: true, trainers: true },
                })
                .then((data) => data.data.data)
                .then((data) => {
                  dispatch(
                    addMeta({
                      branches: data.branches.reduce((branches, branch) => {
                        return { ...branches, [branch.id]: branch.name };
                      }, {}),
                      trianers: data.trainers.reduce((trainers, trainer) => {
                        return { ...trainers, [trainer.id]: trainer.name };
                      }, {}),
                    })
                  );
                })
                .then(() => {
                  try {
                    api
                      .get("api.php?action=subjects")
                      .then((data) => data.data)
                      .then((data) => {
                        dispatch(
                          addCoursesList({
                            coursesList: data.reduce((courses, course) => {
                              return { ...courses, [course.id]: course.name };
                            }, {}),
                          })
                        );
                      })
                      .then(() => {
                        try {
                          api
                            .get("api.php?action=online", {
                              params: {
                                oAction: "list",
                              },
                            })
                            .then((data) => data.data.data)
                            .then((data) =>
                              Object.keys(data).forEach((diploma) => {
                                console.log(data);
                                dispatch(
                                  addOnlineDiploma({
                                    diploma: {
                                      id: diploma,
                                      name: diplomasList[diploma],
                                    },
                                  })
                                );
                                Object.keys(data[diploma]).forEach((course) => {
                                  console.log({
                                    ...data[diploma][course],
                                    diploma: diploma,
                                    id: course,
                                  });
                                  dispatch(
                                    addOnlinePeriod({
                                      ...data[diploma][course],
                                      diploma: diploma,
                                      id: course,
                                      isNew: false,
                                    })
                                  );
                                });
                              })
                            );
                        } catch (e) {
                          console.log(e);
                        }
                      });
                  } catch (e) {
                    console.log(e);
                  }
                });
            } catch (e) {
              console.log(e);
            }
          });
      } catch (e) {
        console.log(e);
      }
    };
    apiCall();
  }, []);

  return (
    <Flex
      color={"black"}
      bg={design.colors.secondary}
      flexDir={"column"}
      maxW={"83%"}
      p={".5rem"}
      borderRadius={"1rem"}
    >
      <Flex w={"100%"} justifyContent={"center"} gap={"1rem"} mb={"1rem"}>
        <Select
          onChange={(e) => {
            setCurrentDiploma(e.value);
          }}
          className="selectDisplay"
          classNamePrefix="select"
          isDisabled={false}
          isLoading={false}
          isRtl={true}
          isSearchable={true}
          options={Object.keys(diplomasList || {}).map((course) => {
            return { value: course, label: diplomasList[course] };
          })}
          placeholder={"اضافة دبلوم"}
        />
        <Button
          sx={design.button.primary}
          onClick={() => {
            currentDiploma
              ? dispatch(
                  addOnlineDiploma({
                    diploma: {
                      id: currentDiploma,
                      name: diplomasList[currentDiploma],
                    },
                  })
                )
              : undefined;
          }}
        >
          اضافة دبلوم جديد
        </Button>
      </Flex>
      <OnlineDiplomas />
    </Flex>
  );
}
