import { Container, Flex, Grid, Heading, Text } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import Sidebar from "./sidebar/Sidebar";
import Login from "../login/Login";

export default function WebContainer() {
  const [currentPage, newPage] = useState(<Login />);
  const [authorized, setAuthorized] = useState(
    document.cookie == "authorization:123"
  );
  const [currentTitle, newTitle] = useState("الجداول");

  return (
    <Grid
      height={"100dvh"}
      minH={"100dvh"}
      maxH={"100dvh"}
      templateColumns={"15rem auto"}
    >
      <Sidebar
        changePage={newPage}
        authorized={authorized}
        setAuthorized={setAuthorized}
        changeTitle={newTitle}
      />
      <Flex
        direction={"column"}
        alignItems={"center"}
        gap={"1rem"}
        w={"auto"}
        m={0}
        mt={"1rem"}
        pr={".5rem"}
      >
        <Heading>{authorized ? currentTitle : ""}</Heading>
        {authorized ? (
          currentPage
        ) : (
          <Login
            setAuthorized={setAuthorized}
            changePage={newPage}
            changeTitle={newTitle}
          />
        )}
      </Flex>
    </Grid>
  );
}
