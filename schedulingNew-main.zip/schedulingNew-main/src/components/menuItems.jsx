import Calendar from "/public/Calendar";
import Teachers from "./TeachersTables/Teachers";
import GroupsContainer from "./groupsTables/GroupsContainer";
import DiplomasContainer from "./DiplomaTables/DiplomasContainer";
import ClassesBuild from "./Classes/ClassesBuild";
import Statistics from "./statistics/Statistics";
import ScheduleTablesContainer from "./Schedule/ScheduleTablesContainer";
import Group from "../../public/Group";
import Teacher from "../../public/Teacher";
import Book from "../../public/Book";
import Desk from "../../public/Desk";
import Graph from "../../public/Graph";
import OnlineContainer from "./OnlineDepartment/OnlineContainer";

const menuPages = {
  الجداول: [<Calendar />, <ScheduleTablesContainer />],
  الشعب: [<Group />, <GroupsContainer />],
  المدربين: [<Teacher />, <Teachers />],
  المواد: [<Book />, <DiplomasContainer />],
  القاعات: [<Desk />, <ClassesBuild />],
  الاحصائيات: [<Graph />, <Statistics />],
  "التعليم الالكتروني": [<Desk />, <OnlineContainer />],
};

const accessPages = {
  الجداول: ["branch"],
  الشعب: ["branch"],
  المدربين: ["branch"],
  المواد: ["branch"],
  القاعات: ["branch"],
  الاحصائيات: [],
  "التعليم الالكتروني": ["online"],
};

const getPages = (branch) => {
  return Object.keys(accessPages)
    .filter((page) => {
      return accessPages[page].includes(branch);
    })
    .map((page) => {
      return [page, menuPages[page]];
    });
};
export { getPages };
