import { Image } from "@chakra-ui/react";
import React from "react";
import "./Loading.css";

export default function Loading(props) {
  return (
    <>
      <Image
        src="/public/AOL_pattern.svg"
        backgroundSize={"cover"}
        h={props.h ? props.h : "50svh"}
        className="rotating"
      />
    </>
  );
}
