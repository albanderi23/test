import { Button, Flex, Grid, Heading } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import { design } from "../../style/mainStyle";

export default function Statistics() {
  const groups = {
    "امن سيبراني": [1, 0, 0, 3, 1, 3, 2, 0],
    "موارد بشرية": [2, 0, 3, 4, 1, 3, 5, 0],
    "الصحة والسلامة المهنية": [1, 3, 4, 1, 3, 0, 0, 0],
  };
  const diplomas = {
    "امن سيبراني": {
      1: [
        ["مقدمة تطبيقات الحاسب", "lab", 4],
        ["خوارزميات", "theory", 4],
        ["انجليزي", "online", 4],
      ],
      2: [
        ["تطبيقات الحاسب المتقدمة", "lab", 6],
        ["تكنولوجيا المعلومات والاتصالات", "theory", 4],
        ["التعرف على عالم الاعامل(1)", "online", 4],
        ["اساسيات التشفير", "theory", 2],
        ["انجليزي 2", "theory", 2],
      ],
      3: [
        ["تطبيقات الحاسب المتقدمة", "lab", 6],
        ["تكنولوجيا المعلومات والاتصالات", "theory", 4],
        ["التعرف على عالم الاعامل(1)", "online", 4],
        ["اساسيات التشفير", "theory", 2],
        ["انجليزي 2", "theory", 2],
      ],
      4: [
        ["تطبيقات الحاسب المتقدمة", "lab", 6],
        ["تكنولوجيا المعلومات والاتصالات", "theory", 4],
        ["التعرف على عالم الاعامل(1)", "online", 4],
        ["اساسيات التشفير", "theory", 2],
        ["انجليزي 2", "theory", 2],
      ],
      5: [
        ["تطبيقات الحاسب المتقدمة", "lab", 6],
        ["تكنولوجيا المعلومات والاتصالات", "theory", 4],
        ["التعرف على عالم الاعامل(1)", "online", 4],
        ["اساسيات التشفير", "theory", 2],
        ["انجليزي 2", "theory", 2],
      ],
      6: [
        ["تطبيقات الحاسب المتقدمة", "lab", 6],
        ["تكنولوجيا المعلومات والاتصالات", "theory", 4],
        ["التعرف على عالم الاعامل(1)", "online", 4],
        ["اساسيات التشفير", "theory", 2],
        ["انجليزي 2", "theory", 2],
      ],
      7: [
        ["تطبيقات الحاسب المتقدمة", "lab", 6],
        ["تكنولوجيا المعلومات والاتصالات", "theory", 4],
        ["التعرف على عالم الاعامل(1)", "online", 4],
        ["اساسيات التشفير", "theory", 2],
        ["انجليزي 2", "theory", 2],
      ],
      8: [
        ["تطبيقات الحاسب المتقدمة", "lab", 6],
        ["تكنولوجيا المعلومات والاتصالات", "theory", 4],
        ["التعرف على عالم الاعامل(1)", "online", 4],
        ["اساسيات التشفير", "theory", 2],
        ["انجليزي 2", "theory", 2],
      ],
    },
    "موارد بشرية": {
      1: [
        ["مقدمة تطبيقات الحاسب", "lab", 4],
        ["ثقافة اسلامية 1", "online", 4],
        ["انجليزي", "online", 4],
      ],
      2: [
        ["تطبيقات الحاسب المتقدمة", "lab", 6],
        ["تكنولوجيا المعلومات والاتصالات", "theory", 4],
        ["التعرف على عالم الاعامل(1)", "online", 4],
        ["اساسيات التشفير", "theory", 2],
        ["انجليزي", "theory", 2],
      ],
    },
    "الصحة والسلامة المهنية": {
      1: [
        ["مقدمة تطبيقات الحاسب", "lab", 4],
        ["ثقافة اسلامية 1", "online", 4],
        ["انجليزي", "online", 4],
      ],
      2: [
        ["تطبيقات الحاسب المتقدمة", "lab", 6],
        ["تكنولوجيا المعلومات والاتصالات", "theory", 4],
        ["التعرف على عالم الاعامل(1)", "online", 4],
        ["اساسيات التشفير", "theory", 2],
        ["انجليزي", "theory", 2],
      ],
    },
  };

  const detailsDesign = {
    border: "solid 1px silver",
    w: "100%",
    justifyContent: "center",
  };
  const [currentStatistics, updateCurrentStatistics] = useState(
    Object.keys(diplomas)[0]
  );
  const [allStatistics, refresh] = useState(
    Object.keys(diplomas).map((diploma) => (
      <Button
        border={"1px silver solid"}
        flexGrow={1}
        borderRadius={"0"}
        bg={"#f0f0f0"}
        boxShadow={
          diploma == currentStatistics ? "inset 0 5px 10px 0 silver" : undefined
        }
        sx={{
          ":hover": {
            bg: "silver",
          },
        }}
        width={"fit-content"}
        key={diploma}
        onClick={() => {
          updateCurrentStatistics(diploma);
        }}
      >
        {diploma}
      </Button>
    ))
  );

  useEffect(() => {
    refresh(
      Object.keys(diplomas).map((diploma) => (
        <Button
          border={"1px silver solid"}
          flexGrow={1}
          borderRadius={"0"}
          bg={diploma == currentStatistics ? "#d0d0d0" : "#f0f0f0"}
          boxShadow={
            diploma == currentStatistics
              ? "inset 0 5px 10px 0 silver"
              : undefined
          }
          sx={{
            ":hover": {
              bg: "silver",
            },
          }}
          width={"fit-content"}
          key={diploma}
          onClick={() => {
            updateCurrentStatistics(diploma);
          }}
        >
          {diploma}
        </Button>
      ))
    );
  }, [currentStatistics]);
  const [statistics, updateStatistics] = useState(<></>);

  useEffect(() => {
    if (
      currentStatistics &&
      diplomas &&
      Object.keys(diplomas).includes(currentStatistics)
    ) {
      updateStatistics(
        [["lab", "معمل"], ["theory", "نظري"], , ["online", "اونلاين"]].map(
          (type) => (
            <React.Fragment key={type}>
              <Flex fontWeight={"bold"} sx={detailsDesign}>
                {type[1]}
              </Flex>
              {Object.keys(diplomas[currentStatistics]).map((val, index) => (
                <Flex sx={detailsDesign} key={val}>
                  {diplomas[currentStatistics][val]
                    .filter((course) => course[1] == type[0])
                    .map((course) => course[2])
                    .reduce((prev = 0, current, arr) => prev + current, 0) *
                    groups[currentStatistics][val - 1]}{" "}
                  ساعات
                </Flex>
              ))}
            </React.Fragment>
          )
        )
      );
    }
  }, [currentStatistics]);
  return (
    <Flex w={"90%"} flexDir={"column"} gap={"3rem"}>
      <Flex flexDir={"column"} w={"80%"} alignSelf={"center"}>
        <Heading size={"lg"} textAlign={"center"}>
          احصائيات
        </Heading>
        <Flex
          mt={"1rem"}
          alignSelf={"center"}
          flexDir={"row"}
          bg={design.colors.secondary}
          borderRadius={"1rem 1rem 0 0"}
          overflow={"hidden"}
        >
          {allStatistics}
        </Flex>
        <Flex
          bg={design.colors.secondary}
          color={design.colors.primary}
          w={"100%"}
          p={".5rem"}
        >
          <Grid
            sx={{ textAlign: "center" }}
            width={"100%"}
            templateColumns={"repeat(9,auto)"}
            justifyItems={"center"}
          >
            <Flex fontWeight={"bold"} sx={detailsDesign}>
              المستوى
            </Flex>
            {Array.from(Array(8).keys()).map((index) => (
              <Flex fontWeight={"bold"} sx={detailsDesign} key={index}>
                {index + 1}
              </Flex>
            ))}
            {statistics}
          </Grid>
        </Flex>
      </Flex>
    </Flex>
  );
}
