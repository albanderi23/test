import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: { lab: [], theory: [] },
};

const ClassesSlice = createSlice({
  name: "classes",
  initialState,
  reducers: {
    updateClass: (state, action) => {
      if (!state.value[action.payload.type][action.payload.id]) {
        return;
      }
      state.value[action.payload.type][action.payload.id] = {
        ...state.value[action.payload.type][action.payload.id],
        ...action.payload.updates,
      };
    },
    replaceClass: (state, action) => {
      const newRoom = action.payload.room;
      const updatedList = Object.keys(state.value[newRoom.type]).reduce(
        (rooms, room) => {
          if (state.value[newRoom.type][room].isDeleted) {
            return { ...rooms };
          }
          return room == newRoom.temp_id
            ? {
                ...rooms,
                [newRoom.room_id]: {
                  className: newRoom.name || "",
                  newName: newRoom.name || "",
                  isDeleted: false,
                  isNew: false,
                  capacity: newRoom.capacity,
                },
              }
            : {
                ...rooms,
                [room]: {
                  className: state.value[newRoom.type][room].name,
                  newName: state.value[newRoom.type][room].name,
                  isDeleted: false,
                  isNew: false,
                  capacity: state.value[newRoom.type][room].capacity,
                },
              };
        },
        {}
      );
      state.value[newRoom.type] = updatedList;
    },
    addClass: (state, action) => {
      if (!state.value[action.payload.type][action.payload.id]) {
        state.value[action.payload.type] = {
          ...state.value[action.payload.type],
          [action.payload.id]: {
            className: action.payload.className || "",
            newName: action.payload.className || "",
            isDeleted: false,
            isNew: action.payload.isNew || false,
            capacity: action.payload.capacity || 0,
          },
        };
      }
    },
    deleteClass: (state, action) => {
      if (state.value[action.payload.type][action.payload.id].isNew) {
        const filteredClasses = Object.keys(state.value[action.payload.type])
          .filter((id) => id != action.payload.id)
          .reduce((classes, currentClass) => {
            return {
              ...classes,
              [currentClass]: state.value[action.payload.type][currentClass],
            };
          }, {});
        state.value[action.payload.type] = filteredClasses;
      } else {
        state.value[action.payload.type] = {
          ...state.value[action.payload.type],
          [action.payload.id]: {
            ...state.value[action.payload.type][action.payload.id],
            isDeleted:
              !state.value[action.payload.type][action.payload.id].isDeleted,
          },
        };
      }
    },
  },
});

export const { deleteClass, addClass, updateClass, replaceClass } =
  ClassesSlice.actions;
export default ClassesSlice.reducer;
