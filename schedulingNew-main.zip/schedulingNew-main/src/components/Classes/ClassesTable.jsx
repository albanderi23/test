import {
  Button,
  Flex,
  Heading,
  Input,
  Table,
  Tbody,
  Text,
  Th,
  Thead,
  Tr,
} from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import ClassContainer from "./ClassContainer";
import { design } from "../../style/mainStyle";
import { useDispatch, useSelector } from "react-redux";
import { addClass } from "./ClassesSlice";

export default function ClassesTable(params) {
  const [roomsList, updateRoomsList] = useState([]);
  const [currentRoomsChanges, updateCurrentRoomsChanges] = useState({});
  const [currentRoomsChangesCollected, updateCurrentRoomsChangesCollected] =
    useState({});
  const [currentDisplay, updateCurrentDisplay] = useState(<></>);
  const [currentID, setID] = useState(params.rooms.length);
  const [size, updateSize] = useState(0);
  const [newRoomsInput, updateNewRoomsInput] = useState(0);
  const [newRoom, updateNewRooms] = useState([]);
  const [newRoomsChanges, updateNewRoomsChanges] = useState({});
  const [newDisplay, updateNewDisplay] = useState(<></>);

  const dispatch = useDispatch();
  const classTableSelector = useSelector(
    (state) => state.classes.value[params.name == "معمل" ? "lab" : "theory"]
  );
  useEffect(() => {}, [classTableSelector]);

  // useEffect(() => {
  //   updateCurrentRoomsChangesCollected({
  //     ...currentRoomsChangesCollected,
  //     ...currentRoomsChanges,
  //   });
  // }, [currentRoomsChanges]);

  // useEffect(() => {
  //   params.update({ ...currentRoomsChangesCollected });
  // }, [currentRoomsChangesCollected]);

  useEffect(() => {
    const currentRooms = params.rooms;
    updateRoomsList(currentRooms);
    updateCurrentDisplay(
      Object.keys(classTableSelector).map((id, index) => {
        const room = classTableSelector[id];
        // updateCurrentRoomsChanges({ ...currentRoomsChanges, [room.id]: {} });
        return (
          <Tr
            key={index}
            transition={".3s"}
            background={
              classTableSelector[id].isDeleted
                ? classTableSelector[id].isNew
                  ? "linear-gradient(233deg,rgba(193, 240, 200, 1) 0%, rgba(255, 169, 169, 1) 100%)"
                  : design.colors.deleted
                : classTableSelector[id].isNew
                ? design.colors.added
                : design.colors.secondary
            }
          >
            <ClassContainer
              name={room.className}
              state={"current"}
              id={id}
              capacity={room.capacity}
              changes={currentRoomsChanges}
              newChanges={updateCurrentRoomsChanges}
              bg={design.colors.secondary}
              type={
                params.name == "معمل"
                  ? "lab"
                  : params.name == "قاعة"
                  ? "theory"
                  : "online"
              }
            />
          </Tr>
        );
      })
    );
  }, [classTableSelector]);

  useEffect(() => {
    const currentRooms = Array.from(Array(size).keys()).map((val, index) => {
      setID(currentID + 1);
      return { name: "", capacity: 0, id: `new${currentID}` };
    });
    updateRoomsList([...roomsList, ...currentRooms]);
    updateNewDisplay(
      [...newRoom, ...currentRooms].map((room, index) => {
        return (
          <Tr key={index} bg={design.colors.added} transition={".3s"}>
            <ClassContainer
              id={room.id}
              name={room.name}
              capacity={room.capacity}
              state={"new"}
              changes={currentRoomsChanges}
              newChanges={updateCurrentRoomsChanges}
              bg={design.colors.added}
              type={
                params.name == "معمل"
                  ? "lab"
                  : params.name == "قاعة"
                  ? "theory"
                  : "online"
              }
            />
          </Tr>
        );
      })
    );
  }, [size]);
  return (
    <Flex
      color={design.colors.primary}
      bg={design.colors.secondary}
      borderRadius={"1rem"}
      gap={"10px"}
      width={"90%"}
      flexDir={"column"}
      justifyContent={"center"}
      overflow={"hidden"}
    >
      <Heading textAlign={"center"} size={"lg"}>
        {params.name}
      </Heading>
      <Flex
        bg={design.colors.secondary}
        color={design.colors.primary}
        border={`1px solid silver`}
        padding={".5rem 1rem"}
        borderRadius={"1rem"}
        gap={"10px"}
        alignItems={"center"}
        width={"95%"}
        alignSelf={"center"}
      >
        <Text sx={{ textWrap: "noWrap" }} fontWeight={"bold"} fontSize={"lg"}>
          غرف اضافية
        </Text>
        <Input
          type="number"
          value={newRoomsInput}
          onChange={(e) => {
            updateNewRoomsInput(e.target.value);
          }}
          sx={{ boxShadow: "inner", bg: "white", color: design.colors.primary }}
        />
        <Button
          sx={design.button.primary}
          w={"8rem"}
          onClick={() => {
            // updateSize(size + parseInt(newRoomsInput));
            Array.from(Array(parseInt(newRoomsInput)).keys()).map((room) => {
              const id =
                "new" +
                Date.now().toString(36) +
                Math.random().toString(36).slice(2);
              dispatch(
                addClass({
                  type: params.name == "معمل" ? "lab" : "theory",
                  isNew: true,
                  id: id,
                })
              );
            });
          }}
        >
          اضافة
        </Button>
      </Flex>
      <Table textAlign={"center"} width={"100%"}>
        <Thead>
          <Tr>
            {["القاعة", "السعة", ""].map((val) => (
              <Th
                fontSize={"20px"}
                borderBottom={`solid 1px ${design.colors.primary}`}
                textAlign={"center"}
                color={design.colors.primary}
                key={val}
              >
                {val}
              </Th>
            ))}
          </Tr>
        </Thead>
        <Tbody>
          {currentDisplay}
          {newDisplay}
        </Tbody>
      </Table>
    </Flex>
  );
}
