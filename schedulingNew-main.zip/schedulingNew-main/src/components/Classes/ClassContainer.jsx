import { Button, Flex, Input, Td } from "@chakra-ui/react";
import React, { act, useEffect, useState } from "react";
import { design } from "../../style/mainStyle";
import Delete from "../../../public/Delete";
import { useDispatch, useSelector } from "react-redux";
import { deleteClass, updateClass } from "./ClassesSlice";

export default function ClassContainer(params) {
  const inputStyle = {
    boxShadow: "inner",
    color: design.colors.primary,
    border: "1px solid silver",
  };
  const classSelector = useSelector(
    (state) => state.classes.value[params.type][params.id]
  );

  const dispatch = useDispatch();

  const [name, updateName] = useState(
    classSelector && classSelector.className ? classSelector.className : ""
  );
  const [changedName, updateChangedName] = useState("white");
  const [capacity, updateCapacity] = useState(
    classSelector && classSelector.capacity ? classSelector.capacity : 0
  );
  const [changedCapacity, updateChangedCapacity] = useState("white");
  const [action, setAction] = useState("");

  useEffect(() => {
    if (name.length == 0) {
      updateChangedName(design.colors.deleted);
    } else if (name == params.name) {
      updateChangedName("white");
    } else {
      updateChangedName(design.colors.added);
    }
    params.newChanges({
      ...params.changes,
      [params.id]: {
        name: name,
        capacity: capacity,
        id: params.id,
        state: params.state,
        action: action,
      },
    });
  }, [name]);

  useEffect(() => {
    if (capacity.length < 1) {
      updateChangedCapacity(design.colors.deleted);
    } else if (capacity == params.capacity) {
      updateChangedCapacity("white");
    } else {
      updateChangedCapacity(design.colors.added);
    }
    params.newChanges({
      ...params.changes,
      [params.id]: {
        name: name,
        capacity: capacity,
        id: params.id,
        type: params.type,
        state: params.state,
        action: action,
      },
    });
  }, [capacity]);

  useEffect(() => {
    if (capacity.length < 1) {
      updateChangedCapacity(design.colors.deleted);
    } else if (capacity == params.capacity) {
      updateChangedCapacity("white");
    } else {
      updateChangedCapacity(design.colors.added);
    }
    params.newChanges({
      ...params.changes,
      [params.id]: {
        name: name,
        capacity: capacity,
        id: params.id,
        type: params.type,
        state: params.state,
        action: action,
      },
    });
  }, [action]);

  const [backgroundColor, setBackgroundColor] = useState(params.bg);

  useEffect(() => {
    if (!classSelector) return;
    if (classSelector.isDeleted) {
      setBackgroundColor(design.colors.deleted);
    } else {
      setBackgroundColor(
        classSelector.isNew ? design.colors.added : design.colors.secondary
      );
    }
  }, [classSelector]);

  return (
    <>
      <Td
        transition={".3s"}
        borderBottom={`1px solid ${design.colors.primary}`}
        width={"40%"}
      >
        <Input
          bg={changedName}
          value={name}
          onChange={(e) => {
            updateName(e.target.value);
            dispatch(
              updateClass({
                type: params.type,
                id: params.id,
                updates: {
                  newName: e.target.value,
                },
              })
            );
          }}
          sx={inputStyle}
        />
      </Td>
      <Td
        transition={".3s"}
        borderBottom={`1px solid ${design.colors.primary}`}
        width={"20%"}
      >
        <Input
          bg={changedCapacity}
          borderBottom={"none"}
          disabled
          onChange={(e) => {
            updateCapacity(e.target.value);
            dispatch(
              updateClass({
                type: params.type,
                id: params.id,
                updates: {
                  newCapacity: e.target.value,
                },
              })
            );
          }}
          value={capacity}
          sx={inputStyle}
        />
      </Td>
      <Td
        transition={".3s"}
        borderBottom={`1px solid ${design.colors.primary}`}
        width={"20%"}
      >
        <Flex
          onClick={() => {
            dispatch(deleteClass({ type: params.type, id: params.id }));
          }}
        >
          <Button sx={design.button.deleted}>حذف</Button>
        </Flex>
      </Td>
    </>
  );
}
