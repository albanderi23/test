import {
  Alert,
  AlertDescription,
  Button,
  Flex,
  Grid,
  Heading,
  Text,
} from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import ClassesTable from "./ClassesTable";
import { design } from "../../style/mainStyle";
import api from "../../api/api";
import Loading from "../Loading";
import AlertingMessage from "../../assets/AlertingMessage";
import { multipleRequest } from "../../api/multipleApi";
import { useDispatch, useSelector } from "react-redux";
import { addClass, replaceClass } from "./ClassesSlice";

export default function ClassesBuild() {
  const loginData = useSelector((state) => state.login.value);
  const [message, setMessage] = useState("");
  const [labs, setLabs] = useState([]);
  const [theory, setTheory] = useState([]);
  const [detectedChange, updateDetectedChange] = useState({});
  const [savedChanges, updateSavedChanges] = useState({});

  const dispatch = useDispatch();
  const classesData = useSelector((state) => state.classes.value);

  useEffect(() => {
    updateSavedChanges({ ...savedChanges, ...detectedChange });
  }, [detectedChange]);

  const [labsTable, updateLabsTable] = useState(
    <Alert status="loading">
      <AlertDescription>
        <Flex width={"fit-content"} alignItems={"center"} gap={"10px"}>
          <Loading h={"2rem"} />
          <Text fontSize={"20px"}>جاري تحميل المعامل</Text>
        </Flex>
      </AlertDescription>
    </Alert>
  );
  const [theoryTable, updateTheoryTable] = useState(
    <Alert status="loading">
      <AlertDescription>
        <Flex width={"fit-content"} alignItems={"center"} gap={"10px"}>
          <Loading h={"2rem"} />
          <Text fontSize={"20px"}>جاري تحميل القاعات</Text>
        </Flex>
      </AlertDescription>
    </Alert>
  );

  useEffect(() => {
    const getData = async () => {
      await api
        .get("api.php?action=rooms", {
          params: { branch: loginData.branch_id },
        })
        .then((res) => res.data)
        .then((data) => {
          console.log(data);
          return Object.values(data).reduce(
            (rooms, room) => {
              return ["lab", "Lab"].includes(room.type)
                ? { ...rooms, lab: [...rooms.lab, room] }
                : { ...rooms, theory: [...rooms.theory, room] };
            },
            { lab: [], theory: [] }
          );
        })
        .then((data) => {
          setLabs(data.lab);
          data.lab.map((lab) => {
            dispatch(
              addClass({
                type: "lab",
                id: lab.id,
                className: lab.name,
                newName: lab.name,
                capacity: lab.capacity,
              })
            );
          });
          setTheory(data.theory);
          data.theory.map((theory) => {
            dispatch(
              addClass({
                type: "theory",
                id: theory.id,
                className: theory.name,
                newName: theory.name,
                capacity: theory.capacity,
              })
            );
          });
          updateLabsTable(
            <ClassesTable
              name={"معمل"}
              rooms={data.lab}
              update={updateDetectedChange}
            />
          );
          updateTheoryTable(
            <ClassesTable
              name={"قاعة"}
              rooms={data.theory}
              update={updateDetectedChange}
            />
          );
        });
    };
  }, []);

  const saveChanges = async () => {
    setMessage(
      <AlertingMessage type={"loading"} message={"جاري حفظ التغييرات"} />
    );
    try {
      await multipleRequest(
        Object.values(savedChanges).map((room) => {
          return room;
        }),
        "patch",
        "patchRooms"
      )
        .then((data) => {
          setMessage(
            <AlertingMessage type={"success"} message={"تم حفظ التغييرات"} />
          );
        })

        .catch((e) => {
          setMessage(
            <AlertingMessage type={"error"} message={"لم يتم حفظ البيانات"} />
          );
        });
    } catch (e) {
      setMessage(
        <AlertingMessage
          type={"error"}
          message={"لم نستطع الوصول الى الخادم"}
        />
      );
    }
  };

  return (
    <>
      <Heading size={"sm"} color={"silver"}>
        ملاحظة: السعة لا تعمل حاليا
      </Heading>
      <Grid templateColumns={"auto auto"} rowGap={"1rem"} alignItems={"start"}>
        <Flex gridColumn={"1 / span 2"} justifyContent={"center"}>
          {message}
        </Flex>
        {labsTable}
        {theoryTable}
        <Button
          sx={design.button.secondary}
          justifySelf={"center"}
          width={"25%"}
          gridColumn={"1 / span 2"}
          onClick={async () => {
            const result = await api
              .post("api.php?action=rooms", {
                branch: loginData.branch_id,
                roomUpdates: classesData,
              })
              .then((res) => {
                return res.data;
              })
              .then((data) => {
                console.log(data);
                Object.values(data).forEach((room) => {
                  dispatch(replaceClass({ room: room.Update }));
                });
              });
          }}
        >
          حفظ التغييرات
        </Button>
      </Grid>
    </>
  );
}
