import { Button, Flex, Img, Text } from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import { design } from "../../style/mainStyle";
import { getPages } from "../menuItems";
import "./sidebar.css";
import Login from "../../login/Login";
import { useDispatch, useSelector } from "react-redux";
import { updateLogin } from "../../login/loginSlice";

export default function Sidebar(props) {
  const changePage = props.changePage;
  const changeTitle = props.changeTitle;
  const loginData = useSelector((state) => state.login.value);
  const dispatch = useDispatch();
  const [menuItems, setMenuItems] = useState([]);
  const flexContainer = {
    flexDir: "column",
  };

  const flexItem = {
    flexDir: "row",
    color: design.colors.primary,
    gap: "1rem",
    py: "1rem",
    px: "1rem",
    alignItems: "center",
    cursor: "pointer",
    transition: ".2s",
    ":hover": {
      bg: "#D0D0D0",
      pr: "1.5rem",
    },
  };

  const [loginButton, updateLoginButton] = useState(
    <Flex
      justifyContent={"center"}
      position={"sticky"}
      bottom={0}
      sx={{ ...flexItem, bg: "silver" }}
      onClick={(e) => {
        changePage(
          <Login
            changePage={changePage}
            changeTitle={changeTitle}
            updateLoginButton={updateLoginButton}
            setAuthorized={props.setAuthorized}
          />
        );
        changeTitle("");
      }}
    >
      <Text textAlign={"center"} fontWeight={"bold"}>
        تسجيل الدخول
      </Text>
    </Flex>
  );

  const loginPage = (
    <Login
      changePage={changePage}
      changeTitle={changeTitle}
      updateLoginButton={updateLoginButton}
      setAuthorized={props.setAuthorized}
    />
  );

  useEffect(() => {
    if (loginData) {
      updateLoginButton(
        <Flex
          justifyContent={"center"}
          position={"sticky"}
          bottom={0}
          sx={{ ...flexItem, bg: "silver" }}
          onClick={(e) => {
            document.cookie = "authorization:";
            props.setAuthorized(false);
            changePage(loginPage);
            changeTitle("");
            dispatch(updateLogin());
          }}
        >
          <Text textAlign={"center"} fontWeight={"bold"}>
            تسجيل الخروج
          </Text>
        </Flex>
      );
    } else {
      updateLoginButton(
        <Flex
          justifyContent={"center"}
          position={"sticky"}
          bottom={0}
          sx={{ ...flexItem, bg: "silver" }}
          onClick={(e) => {
            changePage(loginPage);
            changeTitle("");
          }}
        >
          <Text textAlign={"center"} fontWeight={"bold"}>
            تسجيل الدخول
          </Text>
        </Flex>
      );
    }
    setMenuItems(getPages(loginData ? loginData.branch : ""));
  }, [loginData]);

  return (
    <Flex sx={flexContainer} bg={design.colors.secondary} w={"auto"} h={"auto"}>
      <Img
        src="public/AOL_Logo.png"
        borderBottom={`${design.colors.primary} solid 1px`}
      />
      <Flex flexDir={"column"} height={"100%"} justifyContent={"space-between"}>
        <Flex
          height={"fit-content"}
          flexDir={"column"}
          position={"sticky"}
          top={0}
        >
          {menuItems.map((page, index) => {
            return (
              <Flex
                userSelect={"none"}
                sx={flexItem}
                key={page}
                className={index == 0 ? "active" : undefined}
                onClick={(e) => {
                  let activePage = document.getElementsByClassName("active");
                  if (activePage.length > 0) {
                    activePage[0].classList.remove("active");
                  }
                  e.currentTarget.classList.add("active");
                  changePage(props.authorized ? page[1][1] : loginPage);
                  changeTitle(page[0]);
                }}
              >
                {page[1][0]}
                <Text>{page[0]}</Text>
              </Flex>
            );
          })}
        </Flex>
        {loginButton}
      </Flex>
    </Flex>
  );
}
