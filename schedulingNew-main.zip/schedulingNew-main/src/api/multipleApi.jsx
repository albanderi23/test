import axios from "axios";
import api from "./api";

const multipleRequest = (data, type, link) => {
  const api = axios.create({
    baseURL: "http://localhost:5172/",
  });
  switch (type) {
    case "post":
      return axios.all(data.map((req) => api.post(link + `/${req.id}`, req)));
    case "patch":
      return axios.all(
        data.map((req) => {
          if (req.state == "current") {
            return api.patch(link + `/${req.id}`, req);
          } else {
            return api.post(link, req);
          }
        })
      );
  }
};

const multipleTeacherControl = (teachers) => {
  const api = axios.create({
    baseURL: "http://localhost:5172/teachersData",
  });
  return axios.all(
    Object.keys(teachers)
      .filter(
        (teacher) => !teachers[teacher].isNew || !teachers[teacher].delete
      )
      .map((req) => {
        if (teachers[req].isNew) {
          api.post("", teachers[req]);
        } else {
          api.patch("" + "/" + req, teachers[req]);
        }
      })
  );
};

export { multipleRequest, multipleTeacherControl };
