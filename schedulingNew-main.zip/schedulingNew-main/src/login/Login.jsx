import {
  Alert,
  AlertDescription,
  AlertIcon,
  AlertTitle,
  Container,
  Flex,
  FormControl,
  FormLabel,
  Heading,
  Image,
  Input,
  Text,
} from "@chakra-ui/react";
import React, { useEffect, useState } from "react";
import { design } from "../style/mainStyle";
import api from "../api/api";
import ScheduleTablesContainer from "../components/Schedule/ScheduleTablesContainer";
import { useDispatch, useSelector } from "react-redux";
import { updateLogin } from "./loginSlice";

function Login(props) {
  const changePage = props.changePage;
  const changeTitle = props.changeTitle;
  const updateLoginButton = props.updateLoginButton;
  const dispatch = useDispatch();

  const [loginInfo, updateLoginInfo] = useState({
    user: "",
    pass: "",
  });
  const [err, triggerError] = useState("");
  const checkUser = async () => {
    try {
      const data = await api
        .get(`api.php?action=login`, {
          params: {
            username: loginInfo.user,
            password: loginInfo.pass,
          },
        })
        .then((data) => {
          console.log(data);
          return data.data.data;
        });
      if (data) {
        console.log(data);
        dispatch(
          updateLogin({
            name: data.name,
            branch: data.type,
            branch_id: data.branch_id,
          })
        );
        props.setAuthorized(true);
        changePage(<ScheduleTablesContainer />);
        changeTitle("الجداول");
      } else {
        triggerError(
          <Alert status="error">
            <AlertIcon />
            <AlertDescription sx={{ textWrap: "wrap" }}>
              تأكدت من المستخدم وكلمة المرور؟
            </AlertDescription>
          </Alert>
        );
      }
    } catch (e) {
      console.log(e);
      triggerError(
        <Alert status="error">
          <AlertIcon />
          <AlertDescription>الخادم غير متوفر حاليا.</AlertDescription>
        </Alert>
      );
    }
  };

  const loginForm = (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        checkUser();
      }}
    >
      <Flex
        color={"black"}
        fontFamily={"GE-SS-Two-Medium"}
        flexDir={"column"}
        alignItems={"center"}
      >
        <Image w={"30%"} src="/public/AOL_logo_white.png" />
        <Flex
          w={"fit-content"}
          flexDir={"column"}
          bg={design.colors.secondary}
          border={`2px solid #444D71`}
          borderRadius={"1rem"}
          p="1rem"
        >
          <FormControl isRequired>
            <FormLabel fontSize={design.fonts.primary}>اسم المستخدم</FormLabel>
            <Input
              name="userName"
              w={"20rem"}
              sx={design.input}
              value={loginInfo.user}
              placeholder="UserName"
              onChange={(e) => {
                updateLoginInfo({ ...loginInfo, user: e.target.value });
              }}
            />
          </FormControl>
          <FormControl pt={"20px"} isRequired>
            <FormLabel fontSize={design.fonts.primary}>كلمة المرور</FormLabel>
            <Input
              name="password"
              type="password"
              placeholder="Password"
              sx={design.input}
              value={loginInfo.pass}
              onChange={(e) => {
                updateLoginInfo({ ...loginInfo, pass: e.target.value });
              }}
            />
          </FormControl>
          <Flex
            borderRadius={"1rem"}
            mt={"1rem"}
            w={"100%"}
            flexWrap={"wrap"}
            overflow={"hidden"}
          >
            {err}
          </Flex>
          <Input
            type="submit"
            mt={"1rem"}
            sx={{
              ...design.button.primary,
              ":hover": { boxShadow: "#444D71", borderColor: "#444D71" },
              cursor: "pointer",
            }}
            value="تسجيل الدخول"
          />
        </Flex>
      </Flex>
    </form>
  );

  return <>{loginForm}</>;
}

export default Login;
