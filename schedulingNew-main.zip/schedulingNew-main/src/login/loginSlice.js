import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: {
    name: undefined,
    token: undefined,
    branch: undefined,
  },
};

const loginSlice = createSlice({
  name: "login",
  initialState,
  reducers: {
    updateLogin: function (state, action) {
      state.value = action.payload || initialState;
    },
  },
});

export const { updateLogin } = loginSlice.actions;
export default loginSlice.reducer;
