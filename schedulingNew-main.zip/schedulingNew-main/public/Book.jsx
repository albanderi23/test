import * as React from "react";

const Book = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={props.w ? props.w : "1.5rem"}
    height={props.h ? props.h : "1.5rem"}
    fill="none"
    viewBox="0 0 16 16"
  >
    <path
      fill={props.color ? props.color : "#000"}
      d="M5 0a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h9v-2H4v-2h10V0z"
    ></path>
  </svg>
);

export default Book;
