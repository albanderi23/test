import * as React from "react";

const Desk = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={props.w ? props.w : "1.5rem"}
    height={props.h ? props.h : "1.5rem"}
    viewBox="0 0 32 32"
  >
    <defs>
      <clipPath id="clip-desk">
        <path d="M0 0h32v32H0z"></path>
      </clipPath>
    </defs>
    <g id="desk" clipPath="url(#clip-desk)">
      <g id="Group_3242" data-name="Group 3242" transform="translate(-312 -52)">
        <g id="Group_3241" data-name="Group 3241">
          <g id="Group_3240" data-name="Group 3240">
            <g id="Group_3239" data-name="Group 3239">
              <g id="Group_3238" data-name="Group 3238">
                <g id="Group_3237" data-name="Group 3237">
                  <g id="Group_3236" data-name="Group 3236">
                    <g id="Group_3235" data-name="Group 3235">
                      <path
                        id="Path_4015"
                        fill={props.color ? props.color : "#000"}
                        d="M341.25 61.45h-11.667a1 1 0 0 0 0 2h4.761a5.55 5.55 0 0 1-2.077 3.742h-11.156l-4.462-11.526a1.5 1.5 0 0 0-2.8 1.084l4.833 12.484a1.5 1.5 0 0 0 1.4.958h.771L318.37 76v.006L316.7 79.9a1 1 0 0 0 .528 1.313 1 1 0 0 0 .392.08 1 1 0 0 0 .92-.607l1.4-3.288h14.392l1.4 3.289a1 1 0 0 0 1.84-.788l-4.149-9.706h1.979a1.5 1.5 0 0 0 0-3H335a7.7 7.7 0 0 0 1.363-3.742h4.884a1 1 0 0 0 0-2Zm-7.764 13.95H320.8l2.225-5.205h8.231Z"
                        data-name="Path 4015"
                      ></path>
                    </g>
                  </g>
                </g>
              </g>
            </g>
          </g>
        </g>
      </g>
    </g>
  </svg>
);

export default Desk;
