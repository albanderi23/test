import * as React from "react";

const Minus = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={props.w}
    height={props.h}
    viewBox="0 -12 32 32"
  >
    <g id="SVGRepo_iconCarrier">
      <g
        id="Page-1"
        fill="none"
        fillRule="evenodd"
        stroke="none"
        strokeWidth="1"
      >
        <g
          id="Icon-Set-Filled"
          fill="#ff2e2e"
          transform="translate(-414 -1049)"
        >
          <path
            id="minus"
            d="M442 1049h-24a4 4 0 1 0 0 8h24a4 4 0 1 0 0-8"
          ></path>
        </g>
      </g>
    </g>
  </svg>
);

export default Minus;
