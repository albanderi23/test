import * as React from "react";

const Board = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={props.size}
    height={props.size}
    fill="none"
    viewBox="0 0 24 24"
  >
    <path
      fill={props.color}
      fillRule="evenodd"
      d="M20 1a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3h-6.438l5.078 4.232a1 1 0 1 1-1.28 1.536L13 19.135V22a1 1 0 1 1-2 0v-2.865l-4.36 3.633a1 1 0 1 1-1.28-1.536L10.438 17H4a3 3 0 0 1-3-3V4a3 3 0 0 1 3-3zm0 2a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"
      clipRule="evenodd"
    ></path>
  </svg>
);

export default Board;
