import * as React from "react";

const Arrow = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    xmlSpace="preserve"
    id="Layer_1"
    width={props.size}
    height={props.size}
    fill={props.color}
    version="1.1"
    viewBox="0 0 330.002 330.002"
  >
    <path
      id="XMLID_24_"
      d="M229.966.847a15 15 0 0 0-16.678 4.784l-120 150.004a15 15 0 0 0 .001 18.741l120 149.996a15 15 0 0 0 26.713-9.371v-300A15 15 0 0 0 229.966.847M210.001 272.24l-85.79-107.235 85.79-107.241z"
    ></path>
  </svg>
);

export default Arrow;
